"""
BA2 - Procurement Data Pipeline: Cleaning, KPI Computation, Automated Reporting
Run: python data_pipeline.py
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime

RAW_CSV     = "procurement_data.csv"
CLEAN_CSV   = "procurement_data_clean.csv"
REPORT_XLS  = "BA2_Procurement_Report.xlsx"
REFERENCE_DATE = pd.Timestamp("2024-06-30")
ANOMALY_SIGMA  = 3.0  # Flag invoice amounts > 3 std devs from category mean


# ── 1. LOAD ───────────────────────────────────────────────────────────────────
def load_data(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        raise FileNotFoundError(f"'{path}' not found. Run generate_data.py first.")
    df = pd.read_csv(
        path,
        parse_dates=["order_date", "expected_delivery", "delivery_date"]
    )
    print(f"Loaded {len(df):,} rows from '{path}'")
    return df


# ── 2. CLEAN ──────────────────────────────────────────────────────────────────
def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    original_len = len(df)

    # Drop rows missing critical fields
    df = df.dropna(subset=["po_id", "order_date", "invoice_amount"])

    # Standardize category and supplier name
    df["category"]      = df["category"].str.strip()
    df["supplier_name"] = df["supplier_name"].str.strip()

    # Fill missing delivery dates: use expected_delivery + 7 days
    missing_del = df["delivery_date"].isna().sum()
    df["delivery_date"] = df["delivery_date"].fillna(df["expected_delivery"] + pd.Timedelta(days=7))
    if missing_del:
        print(f"  Filled {missing_del} missing delivery_date values (expected + 7 days)")

    # Ensure delivery_date >= order_date
    bad_delivery = (df["delivery_date"] < df["order_date"]).sum()
    df.loc[df["delivery_date"] < df["order_date"], "delivery_date"] = (
        df.loc[df["delivery_date"] < df["order_date"], "order_date"]
        + pd.Timedelta(days=3)
    )
    if bad_delivery:
        print(f"  Fixed {bad_delivery} rows: delivery_date before order_date")

    # Remove negative or zero invoice amounts
    bad_amounts = (df["invoice_amount"] <= 0).sum()
    df = df[df["invoice_amount"] > 0]
    if bad_amounts:
        print(f"  Removed {bad_amounts} rows: invalid invoice_amount")

    # Flag anomalous invoice amounts (> 3σ from category mean)
    cat_stats = df.groupby("category")["invoice_amount"].agg(["mean", "std"]).reset_index()
    cat_stats.columns = ["category", "cat_mean", "cat_std"]
    df = df.merge(cat_stats, on="category", how="left")
    df["is_anomaly"] = (
        np.abs(df["invoice_amount"] - df["cat_mean"]) > ANOMALY_SIGMA * df["cat_std"]
    ).astype(int)
    anomaly_count = df["is_anomaly"].sum()
    df = df.drop(columns=["cat_mean", "cat_std"])
    print(f"  Flagged {anomaly_count} anomalous invoice amounts (>{ANOMALY_SIGMA}σ from category mean)")

    # Recompute derived fields to ensure consistency
    df["processing_time_days"] = (
        (df["delivery_date"] - df["order_date"]).dt.days
    ).clip(lower=1)

    df["delay_days"] = (
        (df["delivery_date"] - df["expected_delivery"]).dt.days
    ).clip(lower=0)

    df["on_time_delivery"] = (df["delay_days"] == 0).astype(int)

    df["cost_variance"] = (df["approved_amount"] - df["invoice_amount"]).round(2)
    df["cost_variance_pct"] = (
        df["cost_variance"] / df["invoice_amount"] * 100
    ).round(2)

    # Add derived time columns
    df["order_month"]   = df["order_date"].dt.to_period("M").astype(str)
    df["order_quarter"] = df["order_date"].dt.to_period("Q").astype(str)
    df["order_year"]    = df["order_date"].dt.year

    removed = original_len - len(df)
    print(f"  Cleaning complete: {len(df):,} rows remain ({removed} removed)")
    return df


# ── 3. KPIs ───────────────────────────────────────────────────────────────────
def compute_kpis(df: pd.DataFrame) -> dict:
    total_spend         = df["invoice_amount"].sum()
    total_pos           = len(df)
    avg_po_value        = df["invoice_amount"].mean()
    avg_processing      = df["processing_time_days"].mean()
    on_time_rate        = df["on_time_delivery"].mean() * 100
    late_pos            = (df["on_time_delivery"] == 0).sum()
    total_variance      = df["cost_variance"].sum()
    avg_variance_pct    = df["cost_variance_pct"].mean()
    overrun_pos         = (df["cost_variance"] > 0).sum()
    overrun_rate        = overrun_pos / total_pos * 100
    unique_suppliers    = df["supplier_id"].nunique()
    anomaly_pos         = df["is_anomaly"].sum() if "is_anomaly" in df.columns else 0

    return {
        "Total Spend ($)":              round(total_spend, 2),
        "Total POs":                    total_pos,
        "Avg PO Value ($)":             round(avg_po_value, 2),
        "Unique Suppliers":             unique_suppliers,
        "Avg Processing Time (days)":   round(avg_processing, 1),
        "On-Time Delivery Rate (%)":    round(on_time_rate, 2),
        "Late POs":                     int(late_pos),
        "Total Cost Variance ($)":      round(total_variance, 2),
        "Avg Cost Variance (%)":        round(avg_variance_pct, 2),
        "POs with Cost Overrun":        int(overrun_pos),
        "Cost Overrun Rate (%)":        round(overrun_rate, 2),
        "Anomalous Invoices Flagged":   int(anomaly_pos),
    }


# ── 4. SUPPLIER PERFORMANCE ───────────────────────────────────────────────────
def supplier_performance(df: pd.DataFrame) -> pd.DataFrame:
    sup = df.groupby(["supplier_id", "supplier_name"]).agg(
        total_pos             = ("po_id", "count"),
        total_spend           = ("invoice_amount", "sum"),
        avg_po_value          = ("invoice_amount", "mean"),
        avg_processing_days   = ("processing_time_days", "mean"),
        on_time_rate_pct      = ("on_time_delivery", lambda x: x.mean() * 100),
        avg_delay_days        = ("delay_days", "mean"),
        avg_cost_variance_pct = ("cost_variance_pct", "mean"),
        total_cost_variance   = ("cost_variance", "sum"),
        overrun_count         = ("cost_variance", lambda x: (x > 0).sum()),
    ).reset_index()

    sup["overrun_rate_pct"] = (sup["overrun_count"] / sup["total_pos"] * 100).round(2)
    for col in ["total_spend", "avg_po_value", "avg_processing_days",
                "on_time_rate_pct", "avg_delay_days", "avg_cost_variance_pct",
                "total_cost_variance"]:
        sup[col] = sup[col].round(2)

    return sup.sort_values("total_spend", ascending=False).reset_index(drop=True)


# ── 5. CATEGORY TRENDS ────────────────────────────────────────────────────────
def category_trends(df: pd.DataFrame) -> pd.DataFrame:
    cat = df.groupby(["category", "order_month"]).agg(
        po_count              = ("po_id", "count"),
        monthly_spend         = ("invoice_amount", "sum"),
        avg_processing_days   = ("processing_time_days", "mean"),
        on_time_rate          = ("on_time_delivery", "mean"),
    ).reset_index()

    cat["on_time_rate_pct"] = (cat["on_time_rate"] * 100).round(2)
    cat["monthly_spend"]    = cat["monthly_spend"].round(2)
    cat["avg_processing_days"] = cat["avg_processing_days"].round(1)
    cat = cat.drop(columns=["on_time_rate"]).sort_values(["category", "order_month"])
    return cat


# ── 6. PROCESS ANALYSIS ───────────────────────────────────────────────────────
def process_analysis(df: pd.DataFrame) -> pd.DataFrame:
    proc = df.groupby("category").agg(
        total_pos             = ("po_id", "count"),
        avg_processing_days   = ("processing_time_days", "mean"),
        median_processing     = ("processing_time_days", "median"),
        p90_processing        = ("processing_time_days", lambda x: x.quantile(0.90)),
        max_processing        = ("processing_time_days", "max"),
        avg_delay_days        = ("delay_days", "mean"),
        pct_delayed           = ("on_time_delivery", lambda x: (1 - x.mean()) * 100),
        total_spend           = ("invoice_amount", "sum"),
    ).reset_index()

    for col in ["avg_processing_days", "median_processing", "p90_processing",
                "avg_delay_days", "pct_delayed", "total_spend"]:
        proc[col] = proc[col].round(2)

    proc = proc.sort_values("avg_processing_days", ascending=False)
    return proc


# ── 7. DELAY REASON ANALYSIS ──────────────────────────────────────────────────
def delay_analysis(df: pd.DataFrame) -> pd.DataFrame:
    delayed = df[df["delay_days"] > 0].copy()

    by_reason = delayed.groupby("delay_reason").agg(
        occurrences       = ("po_id", "count"),
        avg_delay_days    = ("delay_days", "mean"),
        max_delay_days    = ("delay_days", "max"),
        total_spend       = ("invoice_amount", "sum"),
        avg_cost_variance = ("cost_variance_pct", "mean"),
    ).reset_index()

    total_delays = by_reason["occurrences"].sum()
    by_reason["pct_of_delays"] = (by_reason["occurrences"] / total_delays * 100).round(2)
    for col in ["avg_delay_days", "avg_cost_variance", "total_spend"]:
        by_reason[col] = by_reason[col].round(2)

    return by_reason.sort_values("occurrences", ascending=False).reset_index(drop=True)


# ── 8. ROOT CAUSE ANALYSIS ────────────────────────────────────────────────────
def root_cause_analysis(df: pd.DataFrame) -> pd.DataFrame:
    rca_rows = []

    # RCA 1: Process Delays
    delayed = df[df["delay_days"] > 0]
    delay_by_reason = delayed.groupby("delay_reason").agg(
        count=("po_id", "count"),
        avg_delay=("delay_days", "mean"),
        total_spend=("invoice_amount", "sum"),
    ).reset_index()
    top3_delay = delay_by_reason.nlargest(3, "count")

    for _, r in top3_delay.iterrows():
        rca_rows.append({
            "Category":            "Process Delay",
            "Rank":                len([x for x in rca_rows if x["Category"] == "Process Delay"]) + 1,
            "Driver":              r["delay_reason"],
            "Occurrences":         int(r["count"]),
            "Avg Delay (days)":    round(r["avg_delay"], 1),
            "Affected Spend ($)":  round(r["total_spend"], 2),
            "Recommended Action":  _delay_action(r["delay_reason"]),
        })

    # RCA 2: Cost Variance
    overruns = df[df["cost_variance"] > 0]
    variance_by_cat = overruns.groupby("category").agg(
        count=("po_id", "count"),
        total_variance=("cost_variance", "sum"),
        avg_variance_pct=("cost_variance_pct", "mean"),
    ).reset_index()
    top3_variance = variance_by_cat.nlargest(3, "total_variance")

    for _, r in top3_variance.iterrows():
        rca_rows.append({
            "Category":            "Cost Variance",
            "Rank":                len([x for x in rca_rows if x["Category"] == "Cost Variance"]) + 1,
            "Driver":              r["category"],
            "Occurrences":         int(r["count"]),
            "Avg Delay (days)":    round(r["avg_variance_pct"], 2),
            "Affected Spend ($)":  round(r["total_variance"], 2),
            "Recommended Action":  f"Negotiate fixed-price contracts for {r['category']}; improve scope definition.",
        })

    rca_df = pd.DataFrame(rca_rows)
    rca_df = rca_df.rename(columns={"Avg Delay (days)": "Avg Delay/Variance"})
    return rca_df


def _delay_action(reason: str) -> str:
    mapping = {
        "Budget Approval Pending":  "Implement tiered pre-approval authority to reduce bottlenecks.",
        "Supplier Delay":           "Establish contractual SLAs with penalties; diversify supplier base.",
        "Missing Documentation":    "Automate document checklist at PO creation; reject incomplete submissions.",
        "Price Discrepancy":        "Mandate 3-way matching (PO/GRN/invoice) before payment processing.",
        "Internal Re-routing":      "Streamline approval workflows; set escalation SLAs for re-routed POs.",
        "Compliance Review":        "Build compliance checks into the PO creation form to catch issues earlier.",
    }
    return mapping.get(reason, "Investigate with process owners and set SLA targets.")


# ── MAIN ──────────────────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("  BA2 PROCUREMENT DATA PIPELINE")
    print("=" * 60)

    df_raw = load_data(RAW_CSV)

    print("\n[2] Cleaning data...")
    df = clean_data(df_raw)
    df.to_csv(CLEAN_CSV, index=False)
    print(f"  Saved clean data → {os.path.abspath(CLEAN_CSV)}")

    print("\n[3] Computing KPIs...")
    kpis = compute_kpis(df)
    for k, v in kpis.items():
        if isinstance(v, (int, float)):
            print(f"  {k:<35} {v:>15,}")
        else:
            print(f"  {k:<35} {v}")

    print("\n[4] Supplier performance...")
    sup_perf = supplier_performance(df)

    print("\n[5] Category trends...")
    cat_trends = category_trends(df)

    print("\n[6] Process analysis...")
    proc_anal = process_analysis(df)

    print("\n[7] Delay analysis...")
    delay_anal = delay_analysis(df)

    print("\n[8] Root Cause Analysis...")
    rca = root_cause_analysis(df)
    print("\n  Top Delay Drivers:")
    delay_rca = rca[rca["Category"] == "Process Delay"]
    for _, row in delay_rca.iterrows():
        print(f"    #{int(row['Rank'])}: {row['Driver']} ({row['Occurrences']:,} occurrences)")
    print("\n  Top Cost Variance Drivers:")
    cv_rca = rca[rca["Category"] == "Cost Variance"]
    for _, row in cv_rca.iterrows():
        print(f"    #{int(row['Rank'])}: {row['Driver']} (${row['Affected Spend ($)']:,.0f} overrun)")

    print(f"\n[9] Writing Excel report → '{REPORT_XLS}'...")
    kpi_df = pd.DataFrame(list(kpis.items()), columns=["KPI", "Value"])

    with pd.ExcelWriter(REPORT_XLS, engine="openpyxl") as writer:
        kpi_df.to_excel(writer,      sheet_name="KPI Summary",          index=False)
        sup_perf.to_excel(writer,    sheet_name="Supplier Performance",  index=False)
        cat_trends.to_excel(writer,  sheet_name="Category Trends",       index=False)
        proc_anal.to_excel(writer,   sheet_name="Process Analysis",      index=False)
        delay_anal.to_excel(writer,  sheet_name="Delay Analysis",        index=False)
        rca.to_excel(writer,         sheet_name="RCA",                   index=False)

    print(f"  Saved → {os.path.abspath(REPORT_XLS)}")
    print("\nPipeline complete.")


if __name__ == "__main__":
    main()
