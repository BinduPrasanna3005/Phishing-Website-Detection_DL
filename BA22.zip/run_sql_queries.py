"""
BA2 - SQL Query Runner
Loads procurement CSV into in-memory SQLite and runs all 4 SQL scripts.
Outputs results as Excel sheets in sql_results.xlsx.
Run: python run_sql_queries.py
"""

import os
import sqlite3
import pandas as pd

CSV_FILE   = "procurement_data.csv"
OUTPUT_XLS = "sql_results.xlsx"
SQL_DIR    = "sql"

QUERIES = [
    ("01_supplier_ranking_cte.sql",   "Supplier_Ranking"),
    ("02_rolling_spend_window.sql",   "Rolling_Spend"),
    ("03_top_delayed_pos.sql",        "Top_Delayed_POs"),
    ("04_cost_variance_analysis.sql", "Cost_Variance"),
]


def load_data_to_sqlite(csv_path: str) -> sqlite3.Connection:
    print(f"Loading '{csv_path}' into SQLite...")
    df = pd.read_csv(csv_path)
    conn = sqlite3.connect(":memory:")
    df.to_sql("procurement", conn, if_exists="replace", index=False)
    print(f"  Loaded {len(df):,} rows into table 'procurement'")
    return conn


def run_query(conn: sqlite3.Connection, sql_path: str) -> pd.DataFrame:
    with open(sql_path, "r", encoding="utf-8") as f:
        sql = f.read()
    df = pd.read_sql_query(sql, conn)
    return df


def main():
    if not os.path.exists(CSV_FILE):
        print(f"ERROR: '{CSV_FILE}' not found. Run generate_data.py first.")
        return

    conn = load_data_to_sqlite(CSV_FILE)
    results = {}

    for filename, sheet_name in QUERIES:
        sql_path = os.path.join(SQL_DIR, filename)
        if not os.path.exists(sql_path):
            print(f"  SKIP: {sql_path} not found")
            continue
        print(f"  Running {filename}...")
        try:
            df = run_query(conn, sql_path)
            results[sheet_name] = df
            print(f"    → {len(df):,} rows returned")
        except Exception as e:
            print(f"    ERROR in {filename}: {e}")

    conn.close()

    if results:
        print(f"\nWriting results to '{OUTPUT_XLS}'...")
        with pd.ExcelWriter(OUTPUT_XLS, engine="openpyxl") as writer:
            for sheet, df in results.items():
                df.to_excel(writer, sheet_name=sheet, index=False)
                print(f"  Sheet '{sheet}': {len(df):,} rows")
        print(f"Saved → {os.path.abspath(OUTPUT_XLS)}")
    else:
        print("No results to write.")


if __name__ == "__main__":
    main()
