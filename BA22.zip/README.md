# BA2 — Procurement & Productivity Analytics Dashboard

A portfolio-ready end-to-end procurement analytics project with synthetic data, SQL analysis, Python pipeline, and an interactive Plotly Dash dashboard.

---

## 📁 Folder Structure

```
BA2/
├── generate_data.py          # Step 1 — Generate 60,000 synthetic procurement records
├── run_sql_queries.py        # Step 2 — Run SQL scripts and export results
├── data_pipeline.py          # Step 3 — Clean data, compute KPIs, export Excel report
├── dashboard.py              # Step 4 — Launch interactive Plotly Dash dashboard
├── requirements.txt          # Python dependencies
├── sql/
│   ├── 01_supplier_ranking_cte.sql       # CTE: Supplier ranking by spend & on-time delivery
│   ├── 02_rolling_spend_window.sql       # Window functions: Rolling 3-month spend by category
│   ├── 03_top_delayed_pos.sql            # Subqueries: Top 10 most delayed POs
│   └── 04_cost_variance_analysis.sql     # Aggregations: Cost variance by supplier & category
└── (generated outputs)
    ├── procurement_data.csv              # Raw synthetic dataset (60K rows)
    ├── procurement_data_clean.csv        # Cleaned dataset
    ├── sql_results.xlsx                  # SQL query results (4 sheets)
    └── BA2_Procurement_Report.xlsx       # Full analytics report (6 sheets)
```

---

## ⚙️ Setup

### Install Python dependencies

```bash
pip install -r requirements.txt
```

> Requires Python 3.9+

---

## 🚀 Execution Order

### Step 1 — Generate synthetic data

```bash
python generate_data.py
```

Generates `procurement_data.csv` with 60,000 procurement transaction records including:
- PO ID, supplier details, category, department, cost center
- Order date, expected delivery, actual delivery date
- Invoice amount, approved amount, cost variance
- Processing time, delay days, delay reason, on-time flag
- Payment status, priority, approval levels, fiscal period

Dataset features: 25 realistic suppliers, 8 spend categories, variable processing times.

---

### Step 2 — Run SQL queries

```bash
python run_sql_queries.py
```

Output: `sql_results.xlsx` with sheets:
- **Supplier_Ranking** — Suppliers ranked by spend with composite performance score (CTE)
- **Rolling_Spend** — 3-month rolling spend per category with MoM change (window functions)
- **Top_Delayed_POs** — 10 worst delayed orders with financial impact (subqueries)
- **Cost_Variance** — Cost overrun/saving analysis by supplier (aggregations)

---

### Step 3 — Run data pipeline

```bash
python data_pipeline.py
```

Cleaning rules:
- Missing delivery dates → filled with expected_delivery + 7 days
- Anomalous invoices → flagged if > 3σ from category mean
- Delivery before order → corrected to order_date + 3 days

Output: `BA2_Procurement_Report.xlsx` with sheets:
- **KPI Summary** — 12 headline KPIs
- **Supplier Performance** — All suppliers ranked by spend with OTD and variance metrics
- **Category Trends** — Monthly spend, processing time, OTD rate per category
- **Process Analysis** — Avg, median, P90 processing time per category
- **Delay Analysis** — Delay reasons ranked by frequency with avg impact
- **RCA** — Top 3 process delay drivers and top 3 cost variance drivers with recommendations

---

### Step 4 — Launch the dashboard

```bash
python dashboard.py
```

Opens the dashboard at **http://127.0.0.1:8051**

Dashboard features:
- 8 KPI cards (Total Spend, POs, Processing Time, OTD Rate, Cost Variance, Variance %, Overrun Rate, Unique Suppliers)
- Top 10 suppliers by spend (horizontal bar)
- Monthly spend trend by category (stacked area)
- Supplier spend vs processing time scatter with OTD colour coding (outlier detection)
- Avg processing time by category (bottleneck identification)
- Cost variance by category (overrun/saving)
- On-time delivery rate top 15 suppliers with 80% target line
- Spend split by category (donut chart)
- Top delay reasons (horizontal bar)
- **Filters**: Category, Supplier, Order Year range — all charts update dynamically

---

## 📊 KPIs Covered

| KPI | Description |
|-----|-------------|
| Total Spend | Sum of all invoice amounts |
| Total POs | Count of purchase orders |
| Avg Processing Time | Days from order to delivery |
| On-Time Delivery Rate | % of POs delivered by expected date |
| Total Cost Variance | Approved – Invoiced (positive = overrun) |
| Cost Overrun Rate | % of POs where approved > invoiced |

---

## 🔍 SQL Techniques Demonstrated

- **CTEs** with composite scoring and risk classification
- **Window functions**: `SUM OVER`, `AVG OVER`, `LAG`, `RANK` with `ROWS BETWEEN`
- **Aggregations**: multi-dimension GROUP BY with CASE expressions
- **Subqueries**: inline aggregation and correlated comparison
- **Date functions**: `strftime` for period extraction

---

## 📦 Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3.9+ | All scripts |
| Pandas | Data manipulation |
| NumPy | Statistical distributions |
| SQLite (in-memory) | SQL execution |
| Plotly Dash | Interactive dashboard |
| Dash Bootstrap Components | Layout and styling |
| OpenPyXL | Excel reporting |

---

## 💡 Portfolio Talking Points

1. **Domain Knowledge** — Modelled realistic procurement patterns: supplier reliability, category spend profiles, approval tiers, and cost overrun distributions.
2. **SQL Analytics** — Wrote production-grade SQL with CTEs, rolling window functions, and subquery-based delay ranking.
3. **Data Quality** — Implemented documented cleaning rules for date anomalies, missing values, and statistical outlier detection.
4. **Root Cause Analysis** — Identified process delay drivers and cost variance contributors with actionable recommendations mapped to procurement best practices.
5. **Visualization** — Built a 9-chart interactive dashboard with dynamic filters, scatter outlier detection, and a supplier OTD benchmark line.
