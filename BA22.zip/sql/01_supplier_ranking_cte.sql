-- ============================================================
-- BA2 SQL Script 01: Supplier Ranking by Spend & On-Time Delivery
-- Technique: CTEs, aggregations, RANK window function
-- ============================================================

WITH supplier_stats AS (
    SELECT
        supplier_id,
        supplier_name,
        COUNT(po_id)                              AS total_pos,
        ROUND(SUM(invoice_amount), 2)             AS total_spend,
        ROUND(AVG(invoice_amount), 2)             AS avg_po_value,
        ROUND(AVG(supplier_reliability), 2)       AS reliability_score,
        SUM(on_time_delivery)                     AS on_time_count,
        ROUND(
            100.0 * SUM(on_time_delivery) / COUNT(po_id), 2
        )                                         AS on_time_rate_pct,
        ROUND(AVG(processing_time_days), 1)       AS avg_processing_days,
        ROUND(AVG(delay_days), 1)                 AS avg_delay_days,
        ROUND(SUM(cost_variance), 2)              AS total_cost_variance,
        ROUND(AVG(cost_variance_pct), 2)          AS avg_cost_variance_pct,
        COUNT(CASE WHEN payment_status = 'Disputed' THEN 1 END) AS disputed_invoices
    FROM procurement
    GROUP BY supplier_id, supplier_name
),

supplier_ranked AS (
    SELECT
        *,
        RANK() OVER (ORDER BY total_spend DESC)          AS spend_rank,
        RANK() OVER (ORDER BY on_time_rate_pct DESC)     AS otd_rank,
        RANK() OVER (ORDER BY avg_processing_days ASC)   AS speed_rank,
        -- Composite performance score (weighted)
        ROUND(
            (on_time_rate_pct * 0.40)
            + ((1 - ABS(avg_cost_variance_pct) / 100.0) * 100 * 0.30)
            + (reliability_score * 100 * 0.30),
            2
        )                                                AS composite_score,
        -- Risk tier
        CASE
            WHEN on_time_rate_pct >= 90 AND avg_cost_variance_pct BETWEEN -5 AND 5 THEN 'Low Risk'
            WHEN on_time_rate_pct >= 75 AND avg_cost_variance_pct BETWEEN -15 AND 15 THEN 'Medium Risk'
            ELSE 'High Risk'
        END                                              AS risk_tier
    FROM supplier_stats
)

SELECT
    spend_rank,
    supplier_id,
    supplier_name,
    total_pos,
    total_spend,
    avg_po_value,
    on_time_rate_pct,
    avg_processing_days,
    avg_delay_days,
    avg_cost_variance_pct,
    total_cost_variance,
    disputed_invoices,
    composite_score,
    risk_tier,
    otd_rank,
    speed_rank
FROM supplier_ranked
ORDER BY spend_rank;
