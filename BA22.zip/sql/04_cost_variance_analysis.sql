-- ============================================================
-- BA2 SQL Script 04: Cost Variance Analysis
-- Technique: Aggregations, subqueries, CASE expressions, GROUP BY
-- ============================================================

WITH variance_base AS (
    SELECT
        po_id,
        supplier_id,
        supplier_name,
        category,
        department,
        fiscal_period,
        strftime('%Y-%m', order_date)  AS order_month,
        invoice_amount,
        approved_amount,
        cost_variance,
        cost_variance_pct,
        -- Variance bucket
        CASE
            WHEN cost_variance_pct < -15         THEN 'Large Saving (>15%)'
            WHEN cost_variance_pct BETWEEN -15 AND -5 THEN 'Moderate Saving (5-15%)'
            WHEN cost_variance_pct BETWEEN -5  AND  5 THEN 'Within Budget'
            WHEN cost_variance_pct BETWEEN  5  AND 15 THEN 'Moderate Overrun (5-15%)'
            ELSE                                        'Large Overrun (>15%)'
        END                            AS variance_bucket,
        processing_time_days,
        on_time_delivery,
        priority
    FROM procurement
),

-- Supplier-level cost variance summary
supplier_variance AS (
    SELECT
        supplier_id,
        supplier_name,
        COUNT(po_id)                          AS total_pos,
        ROUND(SUM(invoice_amount), 2)         AS total_invoiced,
        ROUND(SUM(approved_amount), 2)        AS total_approved,
        ROUND(SUM(cost_variance), 2)          AS total_variance,
        ROUND(AVG(cost_variance_pct), 2)      AS avg_variance_pct,
        ROUND(MAX(cost_variance_pct), 2)      AS max_overrun_pct,
        ROUND(MIN(cost_variance_pct), 2)      AS max_saving_pct,
        COUNT(CASE WHEN cost_variance > 0 THEN 1 END) AS overrun_count,
        COUNT(CASE WHEN cost_variance < 0 THEN 1 END) AS saving_count,
        COUNT(CASE WHEN cost_variance = 0 THEN 1 END) AS on_budget_count,
        ROUND(
            100.0 * COUNT(CASE WHEN cost_variance > 0 THEN 1 END) / COUNT(po_id), 2
        )                                     AS overrun_rate_pct,
        RANK() OVER (ORDER BY SUM(cost_variance) DESC) AS overrun_rank
    FROM variance_base
    GROUP BY supplier_id, supplier_name
),

-- Category-level cost variance summary
category_variance AS (
    SELECT
        category,
        COUNT(po_id)                          AS total_pos,
        ROUND(SUM(invoice_amount), 2)         AS total_invoiced,
        ROUND(SUM(cost_variance), 2)          AS total_variance,
        ROUND(AVG(cost_variance_pct), 2)      AS avg_variance_pct,
        COUNT(CASE WHEN cost_variance > 0 THEN 1 END) AS overrun_count,
        ROUND(
            100.0 * COUNT(CASE WHEN cost_variance > 0 THEN 1 END) / COUNT(po_id), 2
        )                                     AS overrun_rate_pct,
        ROUND(AVG(processing_time_days), 1)   AS avg_proc_days,
        RANK() OVER (ORDER BY ABS(SUM(cost_variance)) DESC) AS variance_rank
    FROM variance_base
    GROUP BY category
),

-- Monthly variance trend
monthly_variance AS (
    SELECT
        order_month,
        COUNT(po_id)                          AS pos_in_month,
        ROUND(SUM(invoice_amount), 2)         AS monthly_spend,
        ROUND(SUM(cost_variance), 2)          AS monthly_variance,
        ROUND(AVG(cost_variance_pct), 2)      AS avg_variance_pct,
        COUNT(CASE WHEN variance_bucket LIKE '%Overrun%' THEN 1 END) AS overrun_pos,
        COUNT(CASE WHEN variance_bucket LIKE '%Saving%'  THEN 1 END) AS saving_pos
    FROM variance_base
    GROUP BY order_month
)

-- Primary output: supplier variance ranked by total overrun
SELECT
    s.overrun_rank,
    s.supplier_name,
    s.total_pos,
    s.total_invoiced,
    s.total_approved,
    s.total_variance,
    s.avg_variance_pct,
    s.max_overrun_pct,
    s.max_saving_pct,
    s.overrun_count,
    s.saving_count,
    s.overrun_rate_pct
FROM supplier_variance s
ORDER BY s.overrun_rank;
