-- ============================================================
-- BA2 SQL Script 03: Top 10 Most Delayed Purchase Orders
-- Technique: Subqueries, ORDER BY, CASE, CTEs
-- ============================================================

WITH delay_context AS (
    SELECT
        po_id,
        supplier_id,
        supplier_name,
        category,
        department,
        priority,
        order_date,
        expected_delivery,
        delivery_date,
        invoice_amount,
        approved_amount,
        cost_variance,
        cost_variance_pct,
        processing_time_days,
        delay_days,
        delay_reason,
        payment_status,
        approval_levels,
        -- Severity classification
        CASE
            WHEN delay_days = 0        THEN 'On Time'
            WHEN delay_days <= 7       THEN 'Minor Delay (1-7d)'
            WHEN delay_days <= 21      THEN 'Moderate Delay (8-21d)'
            WHEN delay_days <= 45      THEN 'Major Delay (22-45d)'
            ELSE                            'Critical Delay (>45d)'
        END                            AS delay_severity,
        -- Financial impact of delay (estimated holding cost at 0.02% per day)
        ROUND(invoice_amount * 0.0002 * delay_days, 2) AS estimated_holding_cost,
        -- Whether the delay contributed to cost variance
        CASE
            WHEN delay_days > 14 AND cost_variance > 0 THEN 'Likely'
            WHEN delay_days > 7  AND cost_variance > 0 THEN 'Possible'
            ELSE 'Unlikely'
        END                            AS delay_caused_overrun,
        -- Percentile rank of this PO's delay (vs all delayed POs)
        ROUND(
            100.0 * RANK() OVER (ORDER BY delay_days DESC)
            / (SELECT COUNT(*) FROM procurement WHERE delay_days > 0),
            1
        )                              AS delay_percentile
    FROM procurement
    WHERE delay_days > 0
),

-- Aggregate: average delay by category as a benchmark
category_avg_delay AS (
    SELECT
        category,
        ROUND(AVG(delay_days), 1)      AS avg_category_delay
    FROM procurement
    WHERE delay_days > 0
    GROUP BY category
)

SELECT
    d.po_id,
    d.supplier_name,
    d.category,
    d.department,
    d.priority,
    d.order_date,
    d.expected_delivery,
    d.delivery_date,
    d.delay_days,
    d.delay_severity,
    d.delay_reason,
    d.processing_time_days,
    d.invoice_amount,
    d.approved_amount,
    d.cost_variance,
    d.cost_variance_pct,
    d.estimated_holding_cost,
    d.delay_caused_overrun,
    d.payment_status,
    d.approval_levels,
    c.avg_category_delay,
    ROUND(d.delay_days - c.avg_category_delay, 1) AS delay_vs_category_avg
FROM delay_context d
JOIN category_avg_delay c ON d.category = c.category
ORDER BY d.delay_days DESC
LIMIT 10;
