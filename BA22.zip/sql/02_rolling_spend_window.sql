-- ============================================================
-- BA2 SQL Script 02: Rolling 3-Month Spend by Category
-- Technique: Window functions (SUM OVER, LAG, ROWS BETWEEN)
-- ============================================================

WITH monthly_category_spend AS (
    SELECT
        strftime('%Y-%m', order_date)   AS order_month,
        category,
        COUNT(po_id)                    AS po_count,
        ROUND(SUM(invoice_amount), 2)   AS monthly_spend,
        ROUND(AVG(invoice_amount), 2)   AS avg_po_value,
        ROUND(AVG(processing_time_days), 1) AS avg_proc_days,
        SUM(on_time_delivery)           AS on_time_pos,
        COUNT(po_id) - SUM(on_time_delivery) AS late_pos
    FROM procurement
    GROUP BY strftime('%Y-%m', order_date), category
),

spend_with_rolling AS (
    SELECT
        order_month,
        category,
        po_count,
        monthly_spend,
        avg_po_value,
        avg_proc_days,
        on_time_pos,
        late_pos,
        -- 3-month rolling sum of spend per category
        ROUND(SUM(monthly_spend) OVER (
            PARTITION BY category
            ORDER BY order_month
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        ), 2)                           AS rolling_3mo_spend,
        -- 3-month rolling average
        ROUND(AVG(monthly_spend) OVER (
            PARTITION BY category
            ORDER BY order_month
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        ), 2)                           AS rolling_3mo_avg,
        -- Previous month spend for MoM change
        LAG(monthly_spend) OVER (
            PARTITION BY category
            ORDER BY order_month
        )                               AS prev_month_spend,
        -- Cumulative spend per category
        ROUND(SUM(monthly_spend) OVER (
            PARTITION BY category
            ORDER BY order_month
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ), 2)                           AS cumulative_spend,
        -- Running rank of months within category (highest spend = 1)
        RANK() OVER (
            PARTITION BY category
            ORDER BY monthly_spend DESC
        )                               AS monthly_spend_rank
    FROM monthly_category_spend
),

final AS (
    SELECT
        *,
        CASE
            WHEN prev_month_spend IS NULL OR prev_month_spend = 0 THEN NULL
            ELSE ROUND(
                (monthly_spend - prev_month_spend) / prev_month_spend * 100, 2
            )
        END                             AS mom_spend_change_pct,
        -- Spending trend signal
        CASE
            WHEN prev_month_spend IS NULL THEN 'N/A'
            WHEN monthly_spend > prev_month_spend * 1.10 THEN 'Increasing'
            WHEN monthly_spend < prev_month_spend * 0.90 THEN 'Decreasing'
            ELSE 'Stable'
        END                             AS spend_trend
    FROM spend_with_rolling
)

SELECT
    order_month,
    category,
    po_count,
    monthly_spend,
    prev_month_spend,
    mom_spend_change_pct,
    spend_trend,
    rolling_3mo_spend,
    rolling_3mo_avg,
    cumulative_spend,
    avg_proc_days,
    on_time_pos,
    late_pos,
    monthly_spend_rank
FROM final
ORDER BY order_month, category;
