"""
BA2 - Procurement Analytics Dashboard (Plotly Dash)
Displays KPIs, supplier performance, spend trends, and process bottlenecks.
Run: python dashboard.py
Open browser at: http://127.0.0.1:8051
"""

import os
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from dash import Dash, dcc, html, Input, Output
import dash_bootstrap_components as dbc
from datetime import datetime

CSV_FILE = "procurement_data_clean.csv"
RAW_CSV  = "procurement_data.csv"

COLORS = {
    "primary":  "#7C3AED",
    "success":  "#059669",
    "danger":   "#DC2626",
    "warning":  "#D97706",
    "info":     "#0284C7",
    "light_bg": "#F5F3FF",
    "card_bg":  "#FFFFFF",
    "border":   "#E5E7EB",
    "text":     "#111827",
    "muted":    "#6B7280",
}

CATEGORY_COLORS = px.colors.qualitative.Set2


def load_data():
    if os.path.exists(CSV_FILE):
        df = pd.read_csv(CSV_FILE, parse_dates=["order_date", "expected_delivery", "delivery_date"])
    elif os.path.exists(RAW_CSV):
        df = pd.read_csv(RAW_CSV, parse_dates=["order_date", "expected_delivery", "delivery_date"])
    else:
        return None
    df["order_month"] = df["order_date"].dt.to_period("M").astype(str)
    df["order_year"]  = df["order_date"].dt.year
    return df


def compute_kpis(df):
    return {
        "total_spend":       df["invoice_amount"].sum(),
        "total_pos":         len(df),
        "avg_processing":    df["processing_time_days"].mean(),
        "on_time_rate":      df["on_time_delivery"].mean() * 100,
        "total_variance":    df["cost_variance"].sum(),
        "avg_variance_pct":  df["cost_variance_pct"].mean(),
        "overrun_rate":      (df["cost_variance"] > 0).mean() * 100,
        "unique_suppliers":  df["supplier_id"].nunique(),
    }


def kpi_card(title, value, subtitle="", color=COLORS["primary"], icon="📊"):
    return dbc.Card(
        dbc.CardBody([
            html.Div([
                html.Span(icon, style={"fontSize": "22px", "marginRight": "8px"}),
                html.Span(title, style={
                    "fontSize": "12px", "fontWeight": "600",
                    "color": COLORS["muted"], "textTransform": "uppercase",
                    "letterSpacing": "0.5px",
                }),
            ], style={"display": "flex", "alignItems": "center", "marginBottom": "8px"}),
            html.H3(value, style={
                "fontSize": "26px", "fontWeight": "700",
                "color": color, "margin": "0 0 4px 0",
            }),
            html.P(subtitle, style={"fontSize": "12px", "color": COLORS["muted"], "margin": "0"}),
        ]),
        style={
            "border": f"1px solid {COLORS['border']}",
            "borderRadius": "12px",
            "boxShadow": "0 1px 3px rgba(0,0,0,0.08)",
            "height": "100%",
        },
    )


def apply_filters(df, category, supplier, year_range):
    f = df.copy()
    if category != "ALL":
        f = f[f["category"] == category]
    if supplier != "ALL":
        f = f[f["supplier_id"] == supplier]
    f = f[
        (f["order_date"].dt.year >= year_range[0]) &
        (f["order_date"].dt.year <= year_range[1])
    ]
    return f


app = Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    title="BA2 — Procurement Analytics Dashboard",
)

df_global = load_data()


def build_layout():
    if df_global is None:
        return dbc.Container([
            html.Div([
                html.H2("⚠️ Data Not Found", style={"color": COLORS["danger"]}),
                html.P("Run the data generation script first:"),
                html.Code("python generate_data.py"),
            ], style={"padding": "60px", "textAlign": "center"}),
        ], fluid=True)

    categories = sorted(df_global["category"].unique().tolist())
    suppliers  = sorted(df_global[["supplier_id", "supplier_name"]].drop_duplicates()
                        .apply(lambda r: r["supplier_id"], axis=1).tolist())

    return dbc.Container([
        # Header
        dbc.Row([
            dbc.Col([
                html.H1("🛒 Procurement Analytics Dashboard",
                        style={"fontWeight": "700", "color": COLORS["text"], "marginBottom": "4px"}),
                html.P("Spend · Supplier Performance · Process Efficiency · Cost Variance",
                       style={"color": COLORS["muted"]}),
            ], md=8),
            dbc.Col([
                html.Small("Last refreshed: " + datetime.now().strftime("%Y-%m-%d %H:%M"),
                           style={"color": COLORS["muted"]}),
            ], md=4, style={"textAlign": "right", "paddingTop": "12px"}),
        ], className="mb-3 mt-3"),

        # Filters
        dbc.Card([dbc.CardBody([dbc.Row([
            dbc.Col([
                html.Label("Category", style={"fontWeight": "600", "fontSize": "13px"}),
                dcc.Dropdown(
                    id="filter-cat",
                    options=[{"label": "All Categories", "value": "ALL"}] +
                            [{"label": c, "value": c} for c in categories],
                    value="ALL", clearable=False, style={"fontSize": "13px"},
                ),
            ], md=4),
            dbc.Col([
                html.Label("Supplier", style={"fontWeight": "600", "fontSize": "13px"}),
                dcc.Dropdown(
                    id="filter-sup",
                    options=[{"label": "All Suppliers", "value": "ALL"}] +
                            [{"label": f"{row['supplier_id']} – {row['supplier_name']}", "value": row["supplier_id"]}
                             for _, row in df_global[["supplier_id","supplier_name"]].drop_duplicates().iterrows()],
                    value="ALL", clearable=False, style={"fontSize": "13px"},
                ),
            ], md=4),
            dbc.Col([
                html.Label("Order Year Range", style={"fontWeight": "600", "fontSize": "13px"}),
                dcc.RangeSlider(
                    id="filter-year",
                    min=df_global["order_date"].dt.year.min(),
                    max=df_global["order_date"].dt.year.max(),
                    step=1,
                    value=[df_global["order_date"].dt.year.min(), df_global["order_date"].dt.year.max()],
                    marks={y: str(y) for y in range(
                        df_global["order_date"].dt.year.min(),
                        df_global["order_date"].dt.year.max() + 1,
                    )},
                ),
            ], md=4),
        ])])], className="mb-4", style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),

        # KPI Cards
        html.Div(id="kpi-cards", className="mb-4"),

        # Charts Row 1: Spend by Supplier + Monthly Spend Trend
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🏢 Top 10 Suppliers by Spend", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-supplier-spend", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=5),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("📅 Monthly Spend Trend by Category", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-monthly-spend", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=7),
        ], className="mb-4"),

        # Charts Row 2: Scatter (supplier outliers) + Processing time by category
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🔍 Supplier Spend vs Processing Time", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-scatter", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=6),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("⏱️ Avg Processing Time by Category", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-proc-time", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=6),
        ], className="mb-4"),

        # Charts Row 3: Cost variance + On-time delivery by supplier
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("💰 Cost Variance by Category", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-cost-variance", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=6),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("✅ On-Time Delivery Rate – Top 15 Suppliers", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-otd", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=6),
        ], className="mb-4"),

        # Charts Row 4: Spend by category pie + Delay reasons
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🍕 Spend by Category", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-cat-pie", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=5),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🚦 Top Delay Reasons", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-delay-reasons", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=7),
        ], className="mb-5"),

        html.Hr(),
        html.P("BA2 Procurement Analytics Portfolio Project | Built with Python & Plotly Dash",
               style={"textAlign": "center", "color": COLORS["muted"], "fontSize": "12px"}),

    ], fluid=True, style={"backgroundColor": COLORS["light_bg"], "minHeight": "100vh"})


app.layout = build_layout()


# ── Callbacks ─────────────────────────────────────────────────────────────────

@app.callback(
    Output("kpi-cards", "children"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_kpis(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    k = compute_kpis(df)
    return dbc.Row([
        dbc.Col(kpi_card("Total Spend",         f"${k['total_spend']:,.0f}",
                         "Invoice amounts", COLORS["primary"], "💵"), md=3),
        dbc.Col(kpi_card("Total POs",           f"{k['total_pos']:,}",
                         "Purchase orders", COLORS["info"], "📄"), md=3),
        dbc.Col(kpi_card("Avg Processing Time", f"{k['avg_processing']:.1f} days",
                         "Order to delivery", COLORS["warning"], "⏱️"), md=3),
        dbc.Col(kpi_card("On-Time Delivery",    f"{k['on_time_rate']:.1f}%",
                         "Delivery vs expected date", COLORS["success"], "✅"), md=3),
        dbc.Col(kpi_card("Total Cost Variance", f"${k['total_variance']:,.0f}",
                         "Approved – Invoiced", COLORS["danger"], "📊"), md=3),
        dbc.Col(kpi_card("Avg Variance %",      f"{k['avg_variance_pct']:.1f}%",
                         "Positive = overrun", COLORS["warning"], "📐"), md=3),
        dbc.Col(kpi_card("Overrun Rate",        f"{k['overrun_rate']:.1f}%",
                         "POs with cost overrun", COLORS["danger"], "⚠️"), md=3),
        dbc.Col(kpi_card("Unique Suppliers",    f"{k['unique_suppliers']}",
                         "In selected filter", COLORS["info"], "🏢"), md=3),
    ])


@app.callback(
    Output("chart-supplier-spend", "figure"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_supplier_spend(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    sup = df.groupby("supplier_name")["invoice_amount"].sum().nlargest(10).reset_index()
    sup.columns = ["supplier_name", "total_spend"]
    sup = sup.sort_values("total_spend")

    fig = go.Figure(go.Bar(
        y=sup["supplier_name"], x=sup["total_spend"],
        orientation="h",
        marker_color=COLORS["primary"],
        text=[f"${v/1e6:.1f}M" if v >= 1e6 else f"${v:,.0f}" for v in sup["total_spend"]],
        textposition="outside",
    ))
    fig.update_layout(
        margin=dict(t=10, b=40, l=10, r=60),
        xaxis_title="Total Spend ($)",
        plot_bgcolor="white", paper_bgcolor="white",
        xaxis=dict(tickformat="$,.0f"),
    )
    return fig


@app.callback(
    Output("chart-monthly-spend", "figure"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_monthly_spend(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    monthly = df.groupby(["order_month", "category"])["invoice_amount"].sum().reset_index()
    monthly.columns = ["month", "category", "spend"]
    monthly = monthly.sort_values("month")

    fig = px.area(
        monthly, x="month", y="spend", color="category",
        color_discrete_sequence=CATEGORY_COLORS,
        labels={"spend": "Spend ($)", "month": "Month"},
    )
    fig.update_layout(
        margin=dict(t=10, b=50, l=50, r=10),
        plot_bgcolor="white", paper_bgcolor="white",
        xaxis=dict(tickangle=45, tickfont=dict(size=9)),
        yaxis=dict(tickformat="$,.0f"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, font=dict(size=10)),
        hovermode="x unified",
    )
    return fig


@app.callback(
    Output("chart-scatter", "figure"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_scatter(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    sup_agg = df.groupby("supplier_name").agg(
        avg_spend=("invoice_amount", "mean"),
        avg_processing=("processing_time_days", "mean"),
        total_pos=("po_id", "count"),
        on_time=("on_time_delivery", "mean"),
    ).reset_index()

    fig = px.scatter(
        sup_agg, x="avg_processing", y="avg_spend",
        size="total_pos", color="on_time",
        hover_name="supplier_name",
        color_continuous_scale="RdYlGn",
        labels={"avg_processing": "Avg Processing Time (days)",
                "avg_spend": "Avg PO Value ($)",
                "on_time": "On-Time Rate"},
        size_max=30,
    )
    fig.update_layout(
        margin=dict(t=10, b=50, l=60, r=20),
        plot_bgcolor="white", paper_bgcolor="white",
        yaxis=dict(tickformat="$,.0f"),
        coloraxis_colorbar=dict(title="OTD Rate", thickness=12),
    )
    return fig


@app.callback(
    Output("chart-proc-time", "figure"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_proc_time(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    proc = df.groupby("category")["processing_time_days"].mean().reset_index()
    proc.columns = ["category", "avg_days"]
    proc = proc.sort_values("avg_days", ascending=True)

    fig = go.Figure(go.Bar(
        y=proc["category"], x=proc["avg_days"],
        orientation="h",
        marker=dict(
            color=proc["avg_days"],
            colorscale="RdYlGn_r",
            showscale=True,
            colorbar=dict(title="Days", thickness=12),
        ),
        text=[f"{v:.1f}d" for v in proc["avg_days"]],
        textposition="outside",
    ))
    fig.update_layout(
        margin=dict(t=10, b=40, l=10, r=60),
        xaxis_title="Avg Processing Days",
        plot_bgcolor="white", paper_bgcolor="white",
    )
    return fig


@app.callback(
    Output("chart-cost-variance", "figure"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_cost_variance(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    cv = df.groupby("category")["cost_variance"].sum().reset_index()
    cv.columns = ["category", "total_variance"]
    cv = cv.sort_values("total_variance", ascending=False)

    colors = [COLORS["danger"] if v > 0 else COLORS["success"] for v in cv["total_variance"]]

    fig = go.Figure(go.Bar(
        x=cv["category"], y=cv["total_variance"],
        marker_color=colors,
        text=[f"${v:,.0f}" for v in cv["total_variance"]],
        textposition="outside",
    ))
    fig.add_hline(y=0, line_dash="dash", line_color="gray")
    fig.update_layout(
        margin=dict(t=10, b=60, l=60, r=10),
        xaxis=dict(tickangle=20, tickfont=dict(size=10)),
        yaxis_title="Cost Variance ($)",
        plot_bgcolor="white", paper_bgcolor="white",
        yaxis=dict(tickformat="$,.0f"),
    )
    return fig


@app.callback(
    Output("chart-otd", "figure"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_otd(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    otd = df.groupby("supplier_name")["on_time_delivery"].mean().reset_index()
    otd.columns = ["supplier", "otd_rate"]
    otd["otd_pct"] = (otd["otd_rate"] * 100).round(1)
    otd = otd.nlargest(15, "otd_pct").sort_values("otd_pct")

    fig = go.Figure(go.Bar(
        y=otd["supplier"], x=otd["otd_pct"],
        orientation="h",
        marker=dict(
            color=otd["otd_pct"],
            colorscale="RdYlGn",
            cmin=50, cmax=100,
        ),
        text=[f"{v:.1f}%" for v in otd["otd_pct"]],
        textposition="outside",
    ))
    fig.add_vline(x=80, line_dash="dash", line_color="gray",
                  annotation_text="80% target", annotation_position="top")
    fig.update_layout(
        margin=dict(t=30, b=40, l=10, r=60),
        xaxis_title="On-Time Delivery Rate (%)",
        xaxis=dict(range=[0, 115]),
        plot_bgcolor="white", paper_bgcolor="white",
    )
    return fig


@app.callback(
    Output("chart-cat-pie", "figure"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_cat_pie(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    by_cat = df.groupby("category")["invoice_amount"].sum().reset_index()
    fig = px.pie(
        by_cat, values="invoice_amount", names="category",
        color_discrete_sequence=CATEGORY_COLORS,
        hole=0.4,
    )
    fig.update_traces(textposition="inside", textinfo="percent+label")
    fig.update_layout(
        margin=dict(t=10, b=10, l=10, r=10),
        showlegend=False,
        plot_bgcolor="white", paper_bgcolor="white",
    )
    return fig


@app.callback(
    Output("chart-delay-reasons", "figure"),
    Input("filter-cat", "value"),
    Input("filter-sup", "value"),
    Input("filter-year", "value"),
)
def update_delay_reasons(category, supplier, year_range):
    df = apply_filters(df_global, category, supplier, year_range)
    delayed = df[df["delay_days"] > 0].copy()
    if "delay_reason" not in delayed.columns or len(delayed) == 0:
        fig = go.Figure()
        fig.add_annotation(text="No delay data", showarrow=False)
        return fig

    by_reason = delayed.groupby("delay_reason").agg(
        count=("po_id", "count"),
        avg_delay=("delay_days", "mean"),
    ).reset_index().sort_values("count", ascending=True)

    fig = go.Figure(go.Bar(
        y=by_reason["delay_reason"],
        x=by_reason["count"],
        orientation="h",
        marker_color=COLORS["warning"],
        text=by_reason["count"],
        textposition="outside",
    ))
    fig.update_layout(
        margin=dict(t=10, b=40, l=10, r=40),
        xaxis_title="Occurrences",
        plot_bgcolor="white", paper_bgcolor="white",
    )
    return fig


if __name__ == "__main__":
    print("=" * 60)
    print("  BA2 — Procurement Analytics Dashboard")
    print("  Open: http://127.0.0.1:8051")
    print("=" * 60)
    if df_global is None:
        print("WARNING: No dataset found. Run generate_data.py first.")
    app.run(debug=False, host="127.0.0.1", port=8051)
