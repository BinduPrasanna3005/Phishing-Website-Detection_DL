"""
BA2 - Synthetic Procurement Dataset Generator
Generates 60,000+ realistic procurement transaction records.
Run: python generate_data.py
"""

import pandas as pd
import numpy as np
import os
import warnings
from datetime import datetime, timedelta

np.random.seed(2024)

OUTPUT_FILE = "procurement_data.csv"
N_RECORDS   = 60_000

# ── Config ────────────────────────────────────────────────────────────────────
START_DATE = datetime(2021, 1, 1)
END_DATE   = datetime(2024, 6, 30)
DATE_RANGE = (END_DATE - START_DATE).days

CATEGORIES = {
    "IT & Software":          {"weight": 0.18, "avg_amount": 45_000, "std": 20_000, "lead_days": (7,  45)},
    "Office Supplies":        {"weight": 0.15, "avg_amount":  2_500, "std":  1_000, "lead_days": (2,  14)},
    "Professional Services":  {"weight": 0.14, "avg_amount": 80_000, "std": 35_000, "lead_days": (14, 60)},
    "Facilities & Maintenance": {"weight": 0.12, "avg_amount": 15_000, "std":  7_000, "lead_days": (5,  30)},
    "Marketing & Events":     {"weight": 0.10, "avg_amount": 25_000, "std": 12_000, "lead_days": (7,  45)},
    "HR & Training":          {"weight": 0.10, "avg_amount": 18_000, "std":  8_000, "lead_days": (5,  30)},
    "Logistics & Shipping":   {"weight": 0.11, "avg_amount": 12_000, "std":  5_000, "lead_days": (3,  20)},
    "Raw Materials":          {"weight": 0.10, "avg_amount": 95_000, "std": 40_000, "lead_days": (10, 60)},
}

SUPPLIERS = [
    # (id, name, category_affinity, reliability_score, avg_delay_days)
    ("SUP001", "Apex Technologies Ltd",       "IT & Software",         0.92, 2),
    ("SUP002", "BlueStar Office Solutions",   "Office Supplies",       0.88, 1),
    ("SUP003", "Vertex Consulting Group",     "Professional Services", 0.85, 5),
    ("SUP004", "GlobalFacilities Inc",        "Facilities & Maintenance", 0.79, 8),
    ("SUP005", "BrandForce Marketing",        "Marketing & Events",    0.83, 4),
    ("SUP006", "TalentEdge HR Services",      "HR & Training",         0.90, 2),
    ("SUP007", "SwiftLogistics Corp",         "Logistics & Shipping",  0.87, 3),
    ("SUP008", "PrimeMaterials Co",           "Raw Materials",         0.75, 12),
    ("SUP009", "CloudSphere Systems",         "IT & Software",         0.94, 1),
    ("SUP010", "EcoSupply Solutions",         "Office Supplies",       0.82, 3),
    ("SUP011", "ProServ Partners",            "Professional Services", 0.78, 9),
    ("SUP012", "BuildRight Facilities",       "Facilities & Maintenance", 0.71, 15),
    ("SUP013", "EventPro Agency",             "Marketing & Events",    0.80, 6),
    ("SUP014", "LearnSphere Training",        "HR & Training",         0.88, 2),
    ("SUP015", "QuickFreight Ltd",            "Logistics & Shipping",  0.84, 4),
    ("SUP016", "SteelCore Materials",         "Raw Materials",         0.69, 18),
    ("SUP017", "TechVision Software",         "IT & Software",         0.91, 1),
    ("SUP018", "SmartSource Procurement",     "Office Supplies",       0.85, 2),
    ("SUP019", "Delta Consultants",           "Professional Services", 0.82, 6),
    ("SUP020", "FlexiLogistics Group",        "Logistics & Shipping",  0.76, 10),
    ("SUP021", "NovaMaterials Global",        "Raw Materials",         0.80, 7),
    ("SUP022", "FacilityPro Services",        "Facilities & Maintenance", 0.86, 4),
    ("SUP023", "DigitalCraft Media",          "Marketing & Events",    0.88, 3),
    ("SUP024", "PeopleFirst Consulting",      "HR & Training",         0.83, 5),
    ("SUP025", "OmniTech Solutions",          "IT & Software",         0.77, 11),
]

PAYMENT_STATUSES = ["Paid", "Paid", "Paid", "Pending", "Overdue", "Disputed"]
# Weights for payment status
PAY_WEIGHTS = [0.55, 0.15, 0.10, 0.12, 0.06, 0.02]

DEPARTMENTS = ["Finance", "IT", "Operations", "HR", "Marketing", "Procurement",
               "Legal", "R&D", "Sales", "Admin"]

COST_CENTERS = [f"CC{str(i).zfill(3)}" for i in range(100, 130)]

PROCESS_STAGES = ["Requisition", "Approval", "PO Issued", "Delivery", "Invoice", "Payment"]
PROCESS_DELAY_REASONS = [
    "Budget Approval Pending",
    "Supplier Delay",
    "Missing Documentation",
    "Price Discrepancy",
    "Internal Re-routing",
    "Compliance Review",
    None,  # No delay
]


def random_dates_arr(n, start, days):
    offsets = np.random.randint(0, days, n)
    return [start + timedelta(days=int(d)) for d in offsets]


def build_procurement_dataset(n: int) -> pd.DataFrame:
    cat_names   = list(CATEGORIES.keys())
    cat_weights = [CATEGORIES[c]["weight"] for c in cat_names]
    categories  = np.random.choice(cat_names, size=n, p=cat_weights)

    # Match supplier to category with some cross-category noise
    supplier_ids   = []
    supplier_names = []
    sup_reliability = []

    for cat in categories:
        # 70% same-category supplier, 30% any supplier
        same_cat_sups = [s for s in SUPPLIERS if s[2] == cat]
        if same_cat_sups and np.random.rand() < 0.70:
            sup = same_cat_sups[np.random.randint(0, len(same_cat_sups))]
        else:
            sup = SUPPLIERS[np.random.randint(0, len(SUPPLIERS))]
        supplier_ids.append(sup[0])
        supplier_names.append(sup[1])
        sup_reliability.append(sup[3])

    sup_reliability = np.array(sup_reliability)

    # Order dates
    order_dates = random_dates_arr(n, START_DATE, DATE_RANGE)

    # Invoice amounts per category
    invoice_amounts = []
    for cat in categories:
        cfg = CATEGORIES[cat]
        amt = np.random.normal(cfg["avg_amount"], cfg["std"])
        amt = max(amt, 100)
        invoice_amounts.append(round(amt, 2))
    invoice_amounts = np.array(invoice_amounts)

    # Approved amounts: mostly same, sometimes variance
    variance_factors = np.random.normal(1.0, 0.05, size=n)
    variance_factors = np.clip(variance_factors, 0.80, 1.30)
    # 15% have significant variance (cost overrun/underrun)
    overrun_mask = np.random.rand(n) < 0.15
    variance_factors[overrun_mask] = np.random.uniform(1.10, 1.40, size=overrun_mask.sum())
    approved_amounts = np.round(invoice_amounts * variance_factors, 2)

    # Processing time: order → payment
    # Less reliable suppliers → longer processing
    base_processing = np.random.gamma(shape=3, scale=8, size=n)  # avg ~24 days
    reliability_adj = (1 - sup_reliability) * 30
    processing_days = np.round(base_processing + reliability_adj).astype(int)
    processing_days = np.clip(processing_days, 1, 120)

    # Delivery dates
    delivery_dates = [
        order_dates[i] + timedelta(days=int(processing_days[i] * 0.6))
        for i in range(n)
    ]

    # Expected delivery (from category lead time)
    expected_delivery_dates = []
    for i, cat in enumerate(categories):
        lo, hi = CATEGORIES[cat]["lead_days"]
        expected_days = np.random.randint(lo, hi + 1)
        expected_delivery_dates.append(order_dates[i] + timedelta(days=expected_days))

    # On-time: actual <= expected
    on_time = [
        1 if delivery_dates[i] <= expected_delivery_dates[i] else 0
        for i in range(n)
    ]

    # Delay days
    delay_days = [
        max(0, (delivery_dates[i] - expected_delivery_dates[i]).days)
        for i in range(n)
    ]

    # Delay reason
    delay_reasons = []
    for i in range(n):
        if delay_days[i] > 0:
            dr = np.random.choice(PROCESS_DELAY_REASONS[:-1])  # exclude None
        else:
            dr = None
        delay_reasons.append(dr)

    # Payment status
    payment_statuses = np.random.choice(
        ["Paid", "Partially Paid", "Pending", "Overdue", "Disputed"],
        size=n,
        p=[0.65, 0.10, 0.14, 0.07, 0.04]
    )

    # Budget year / quarter
    budget_years = [d.year for d in order_dates]
    budget_quarters = [f"Q{((d.month - 1) // 3) + 1}" for d in order_dates]
    fiscal_periods = [f"{budget_years[i]}-{budget_quarters[i]}" for i in range(n)]

    departments = np.random.choice(DEPARTMENTS, size=n)
    cost_centers = np.random.choice(COST_CENTERS, size=n)

    # PO priority
    priority = np.random.choice(
        ["Low", "Medium", "High", "Critical"],
        size=n,
        p=[0.30, 0.40, 0.22, 0.08]
    )

    # Number of approval levels
    approval_levels = np.where(
        invoice_amounts > 50_000, np.random.randint(3, 5, size=n),
        np.where(invoice_amounts > 10_000, np.random.randint(2, 4, size=n),
                 np.random.randint(1, 3, size=n))
    )

    df = pd.DataFrame({
        "po_id":               [f"PO{str(i+1).zfill(7)}" for i in range(n)],
        "supplier_id":         supplier_ids,
        "supplier_name":       supplier_names,
        "category":            categories,
        "department":          departments,
        "cost_center":         cost_centers,
        "order_date":          [d.strftime("%Y-%m-%d") for d in order_dates],
        "expected_delivery":   [d.strftime("%Y-%m-%d") for d in expected_delivery_dates],
        "delivery_date":       [d.strftime("%Y-%m-%d") for d in delivery_dates],
        "invoice_amount":      invoice_amounts,
        "approved_amount":     approved_amounts,
        "cost_variance":       np.round(approved_amounts - invoice_amounts, 2),
        "cost_variance_pct":   np.round((approved_amounts - invoice_amounts) / invoice_amounts * 100, 2),
        "processing_time_days": processing_days,
        "delay_days":          delay_days,
        "delay_reason":        delay_reasons,
        "on_time_delivery":    on_time,
        "payment_status":      payment_statuses,
        "priority":            priority,
        "approval_levels":     approval_levels,
        "fiscal_period":       fiscal_periods,
        "supplier_reliability": np.round(sup_reliability, 2),
    })

    return df


if __name__ == "__main__":
    if os.path.exists(OUTPUT_FILE):
        warnings.warn(f"WARNING: '{OUTPUT_FILE}' already exists and will be overwritten.")

    print(f"Generating {N_RECORDS:,} procurement records...")
    df = build_procurement_dataset(N_RECORDS)

    on_time_rate = df["on_time_delivery"].mean() * 100
    print(f"  Total POs          : {len(df):,}")
    print(f"  Unique suppliers   : {df['supplier_id'].nunique()}")
    print(f"  Spend categories   : {df['category'].nunique()}")
    print(f"  Total spend        : ${df['invoice_amount'].sum():,.0f}")
    print(f"  On-time delivery   : {on_time_rate:.1f}%")
    print(f"  Avg processing time: {df['processing_time_days'].mean():.1f} days")

    df.to_csv(OUTPUT_FILE, index=False)
    print(f"\nSaved → {os.path.abspath(OUTPUT_FILE)}")
