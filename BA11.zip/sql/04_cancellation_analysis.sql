-- ============================================================
-- BA1 SQL Script 04: Cancellation Root Cause Analysis
-- Technique: GROUP BY aggregations, CASE statements, subqueries
-- ============================================================

WITH churned_customers AS (
    SELECT
        customer_id,
        plan,
        region,
        industry,
        monthly_revenue,
        months_active,
        nps_score,
        cancellation_reason,
        strftime('%Y-%m', cancellation_date) AS churn_month,
        strftime('%Y',    cancellation_date) AS churn_year
    FROM customers
    WHERE is_churned = 1
      AND cancellation_date IS NOT NULL
),

reason_summary AS (
    SELECT
        cancellation_reason,
        COUNT(*)                              AS cancellation_count,
        ROUND(SUM(monthly_revenue), 2)        AS lost_mrr,
        ROUND(AVG(monthly_revenue), 2)        AS avg_mrr_lost,
        ROUND(AVG(months_active), 1)          AS avg_months_before_cancel,
        ROUND(AVG(nps_score), 2)              AS avg_nps_at_cancel,
        ROUND(
            100.0 * COUNT(*) / (SELECT COUNT(*) FROM churned_customers),
            2
        )                                     AS pct_of_cancellations
    FROM churned_customers
    GROUP BY cancellation_reason
),

reason_by_plan AS (
    SELECT
        plan,
        cancellation_reason,
        COUNT(*)                              AS cancellations,
        ROUND(SUM(monthly_revenue), 2)        AS lost_mrr
    FROM churned_customers
    GROUP BY plan, cancellation_reason
),

reason_by_region AS (
    SELECT
        region,
        cancellation_reason,
        COUNT(*)                              AS cancellations,
        ROUND(SUM(monthly_revenue), 2)        AS lost_mrr
    FROM churned_customers
    GROUP BY region, cancellation_reason
),

monthly_churn_trend AS (
    SELECT
        churn_month,
        COUNT(*)                              AS monthly_cancellations,
        ROUND(SUM(monthly_revenue), 2)        AS monthly_lost_mrr,
        -- Rolling: simple monthly counts
        SUM(COUNT(*)) OVER (
            ORDER BY churn_month
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        )                                     AS rolling_3mo_cancellations
    FROM churned_customers
    GROUP BY churn_month
)

-- Primary output: cancellation reason ranked by lost MRR
SELECT
    rs.cancellation_reason,
    rs.cancellation_count,
    rs.pct_of_cancellations,
    rs.lost_mrr,
    rs.avg_mrr_lost,
    rs.avg_months_before_cancel,
    rs.avg_nps_at_cancel,
    RANK() OVER (ORDER BY rs.cancellation_count DESC) AS rank_by_count,
    RANK() OVER (ORDER BY rs.lost_mrr DESC)           AS rank_by_mrr
FROM reason_summary rs
ORDER BY rs.lost_mrr DESC;
