-- ============================================================
-- BA1 SQL Script 03: Customer Lifetime Value Summary
-- Technique: Multi-table joins simulation, subqueries, aggregations
-- ============================================================

WITH plan_benchmarks AS (
    -- Subquery: compute plan-level average CLV as a benchmark
    SELECT
        plan,
        ROUND(AVG(customer_lifetime_value), 2)  AS avg_clv_plan,
        ROUND(AVG(monthly_revenue), 2)           AS avg_mrr_plan,
        COUNT(*)                                 AS plan_customer_count,
        SUM(monthly_revenue)                     AS plan_total_mrr
    FROM customers
    GROUP BY plan
),

customer_segments AS (
    SELECT
        c.customer_id,
        c.plan,
        c.region,
        c.industry,
        c.acquisition_channel,
        c.company_size,
        c.monthly_revenue,
        c.months_active,
        c.customer_lifetime_value                AS clv,
        c.nps_score,
        c.is_churned,
        c.cancellation_reason,
        b.avg_clv_plan,
        b.avg_mrr_plan,
        -- Above or below plan average
        CASE
            WHEN c.customer_lifetime_value > b.avg_clv_plan THEN 'Above Average'
            WHEN c.customer_lifetime_value = b.avg_clv_plan THEN 'Average'
            ELSE 'Below Average'
        END                                      AS clv_vs_plan_avg,
        -- Value segment
        CASE
            WHEN c.customer_lifetime_value >= (
                SELECT PERCENTILE_APPROX_80 FROM (
                    SELECT MAX(sub.clv_80) AS PERCENTILE_APPROX_80
                    FROM (
                        SELECT plan,
                               monthly_revenue * 0.8 AS clv_80
                        FROM customers
                        WHERE plan = c.plan
                        LIMIT 1
                    ) sub
                )
            ) THEN 'High Value'
            WHEN c.customer_lifetime_value >= b.avg_clv_plan * 0.5 THEN 'Mid Value'
            ELSE 'Low Value'
        END                                      AS value_segment
    FROM customers c
    JOIN plan_benchmarks b ON c.plan = b.plan
),

clv_summary AS (
    SELECT
        plan,
        region,
        industry,
        acquisition_channel,
        COUNT(customer_id)                       AS total_customers,
        SUM(CASE WHEN is_churned = 1 THEN 1 ELSE 0 END) AS churned_count,
        ROUND(100.0 * SUM(CASE WHEN is_churned = 1 THEN 1 ELSE 0 END)
              / COUNT(customer_id), 2)           AS churn_rate_pct,
        ROUND(AVG(clv), 2)                       AS avg_clv,
        ROUND(MAX(clv), 2)                       AS max_clv,
        ROUND(MIN(clv), 2)                       AS min_clv,
        ROUND(SUM(clv), 2)                       AS total_clv,
        ROUND(AVG(monthly_revenue), 2)           AS avg_mrr,
        ROUND(AVG(months_active), 1)             AS avg_months_active,
        ROUND(AVG(nps_score), 2)                 AS avg_nps
    FROM customers
    GROUP BY plan, region, industry, acquisition_channel
)

SELECT *
FROM clv_summary
ORDER BY total_clv DESC;
