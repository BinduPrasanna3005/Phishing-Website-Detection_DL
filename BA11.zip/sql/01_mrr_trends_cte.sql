-- ============================================================
-- BA1 SQL Script 01: Monthly Recurring Revenue (MRR) Trends
-- Technique: CTEs, DATE aggregation
-- ============================================================
-- NOTE: This script targets SQLite syntax (used by the Python runner).
--       strftime('%Y-%m', ...) extracts year-month from a date string.

WITH active_monthly AS (
    -- For each customer, generate one row per active month
    -- SQLite approach: filter by signup_month, count as active
    SELECT
        strftime('%Y-%m', signup_date)       AS cohort_month,
        plan,
        region,
        SUM(monthly_revenue)                 AS cohort_mrr,
        COUNT(customer_id)                   AS new_customers
    FROM customers
    GROUP BY
        strftime('%Y-%m', signup_date),
        plan,
        region
),

churned_monthly AS (
    SELECT
        strftime('%Y-%m', cancellation_date) AS churn_month,
        plan,
        SUM(monthly_revenue)                 AS churned_mrr,
        COUNT(customer_id)                   AS churned_customers
    FROM customers
    WHERE is_churned = 1
      AND cancellation_date IS NOT NULL
    GROUP BY
        strftime('%Y-%m', cancellation_date),
        plan
),

mrr_summary AS (
    SELECT
        a.cohort_month,
        a.plan,
        a.region,
        a.cohort_mrr                         AS new_mrr,
        a.new_customers,
        COALESCE(c.churned_mrr, 0)           AS churned_mrr,
        COALESCE(c.churned_customers, 0)     AS churned_customers,
        a.cohort_mrr - COALESCE(c.churned_mrr, 0) AS net_mrr
    FROM active_monthly  a
    LEFT JOIN churned_monthly c
           ON a.cohort_month = c.churn_month
          AND a.plan          = c.plan
)

SELECT
    cohort_month,
    plan,
    region,
    new_customers,
    ROUND(new_mrr, 2)       AS new_mrr,
    churned_customers,
    ROUND(churned_mrr, 2)   AS churned_mrr,
    ROUND(net_mrr, 2)       AS net_mrr
FROM mrr_summary
ORDER BY cohort_month, plan, region;
