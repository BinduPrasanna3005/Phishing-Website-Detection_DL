-- ============================================================
-- BA1 SQL Script 02: Month-over-Month Growth & Customer Rankings
-- Technique: Window functions (LAG, RANK, NTILE, SUM OVER)
-- ============================================================

WITH monthly_revenue AS (
    SELECT
        strftime('%Y-%m', signup_date)  AS month,
        plan,
        COUNT(customer_id)              AS new_signups,
        SUM(monthly_revenue)            AS total_mrr
    FROM customers
    GROUP BY strftime('%Y-%m', signup_date), plan
),

mom_growth AS (
    SELECT
        month,
        plan,
        new_signups,
        ROUND(total_mrr, 2)            AS total_mrr,
        -- LAG to get previous month MRR
        LAG(total_mrr) OVER (
            PARTITION BY plan
            ORDER BY month
        )                              AS prev_mrr,
        -- Month-over-month % change
        CASE
            WHEN LAG(total_mrr) OVER (PARTITION BY plan ORDER BY month) IS NULL
                 OR LAG(total_mrr) OVER (PARTITION BY plan ORDER BY month) = 0
            THEN NULL
            ELSE ROUND(
                (total_mrr - LAG(total_mrr) OVER (PARTITION BY plan ORDER BY month))
                / LAG(total_mrr) OVER (PARTITION BY plan ORDER BY month) * 100,
                2
            )
        END                             AS mom_growth_pct,
        -- Running cumulative MRR per plan
        ROUND(SUM(total_mrr) OVER (
            PARTITION BY plan
            ORDER BY month
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ), 2)                           AS cumulative_mrr,
        -- Rank months by revenue within each plan (1 = highest)
        RANK() OVER (
            PARTITION BY plan
            ORDER BY total_mrr DESC
        )                               AS revenue_rank
    FROM monthly_revenue
),

customer_value_tiers AS (
    SELECT
        customer_id,
        plan,
        region,
        monthly_revenue,
        customer_lifetime_value,
        -- Quartile bucket by CLV within each plan
        NTILE(4) OVER (
            PARTITION BY plan
            ORDER BY customer_lifetime_value ASC
        )                              AS clv_quartile,
        -- Percentile rank
        ROUND(
            100.0 * RANK() OVER (
                PARTITION BY plan
                ORDER BY customer_lifetime_value ASC
            ) / COUNT(*) OVER (PARTITION BY plan),
            1
        )                              AS clv_percentile
    FROM customers
)

-- Output 1: MoM growth table
SELECT
    month,
    plan,
    new_signups,
    total_mrr,
    COALESCE(CAST(prev_mrr AS TEXT), 'N/A')      AS prev_mrr,
    COALESCE(CAST(mom_growth_pct AS TEXT), 'N/A') AS mom_growth_pct,
    cumulative_mrr,
    revenue_rank
FROM mom_growth
ORDER BY month, plan;
