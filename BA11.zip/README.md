# BA1 — Business Analytics Dashboard & KPI Monitoring System

A portfolio-ready end-to-end analytics project simulating a subscription-based SaaS business.
Covers synthetic data generation, SQL analytics, Python data pipeline, and an interactive KPI dashboard.

---

## 📁 Folder Structure

```
BA1/
├── generate_data.py          # Step 1 — Generate 110,000 synthetic customer records
├── run_sql_queries.py        # Step 2 — Run SQL scripts and export results
├── data_pipeline.py          # Step 3 — Clean data, compute KPIs, export Excel report
├── dashboard.py              # Step 4 — Launch interactive Plotly Dash dashboard
├── requirements.txt          # Python dependencies
├── sql/
│   ├── 01_mrr_trends_cte.sql          # CTE: Monthly Recurring Revenue trends
│   ├── 02_window_functions_growth.sql  # Window functions: MoM growth, rankings
│   ├── 03_clv_joins_subqueries.sql     # Joins + subqueries: Customer Lifetime Value
│   └── 04_cancellation_analysis.sql   # Aggregations: Cancellation Root Cause Analysis
└── (generated outputs)
    ├── saas_customers.csv              # Raw synthetic dataset (110K rows)
    ├── saas_customers_clean.csv        # Cleaned dataset
    ├── sql_results.xlsx                # SQL query results (4 sheets)
    └── BA1_Analytics_Report.xlsx       # Full KPI report (6 sheets)
```

---

## ⚙️ Setup

### 1. Install Python dependencies

```bash
pip install -r requirements.txt
```

> Requires Python 3.9+

---

## 🚀 Execution Order

### Step 1 — Generate synthetic data

```bash
python generate_data.py
```

Generates `saas_customers.csv` with 110,000 customer subscription records including:
- Customer ID, signup date, plan, region, industry, acquisition channel
- Monthly revenue, NPS score, support tickets
- Churn status, cancellation date & reason, months active, CLV

---

### Step 2 — Run SQL queries

```bash
python run_sql_queries.py
```

Loads the CSV into an in-memory SQLite database and runs all 4 SQL scripts.
Output: `sql_results.xlsx` with sheets:
- **MRR_Trends** — Monthly recurring revenue by plan and region (CTE)
- **MoM_Growth** — Month-over-month revenue growth with LAG / RANK window functions
- **CLV_Summary** — Customer lifetime value by plan, region, industry (joins + subqueries)
- **Cancellation_RCA** — Cancellation root cause ranked by count and lost MRR

---

### Step 3 — Run data pipeline

```bash
python data_pipeline.py
```

Cleans data, computes KPIs, runs Root Cause Analysis.
Output: `BA1_Analytics_Report.xlsx` with sheets:
- **KPI Summary** — 11 headline KPIs (revenue, churn, ARPU, NPS, etc.)
- **Monthly Trends** — Signups, MRR, cancellations, and net MRR per month
- **Churn Analysis** — Cancellation reasons ranked by frequency and lost MRR
- **Cohort Retention** — Retention rate by signup cohort
- **Plan Performance** — Revenue, churn, CLV metrics per plan tier
- **RCA** — Top 3 cancellation drivers with recommended actions

---

### Step 4 — Launch the dashboard

```bash
python dashboard.py
```

Opens the Plotly Dash dashboard at **http://127.0.0.1:8050**

Dashboard features:
- 8 KPI metric cards (Revenue, MRR, Active Customers, Churn Rate, ARPU, Avg CLV, NPS, Total)
- Monthly revenue trend (area line chart)
- Revenue split by plan (donut chart)
- Cancellation reasons ranked by frequency (horizontal bar)
- Monthly churn trend with dual-axis churn rate (combo chart)
- Cohort retention by signup month (colour-coded bar)
- Customers by region with churn rate overlay
- CLV distribution by plan (histogram)
- NPS distribution by plan (grouped bar)
- **Filters**: Plan, Region, Signup Year range — all charts update dynamically

---

## 📊 KPIs Covered

| KPI | Description |
|-----|-------------|
| Total Revenue | Sum of all customer lifetime values |
| MRR | Monthly recurring revenue (active customers only) |
| Churn Rate | % of customers who cancelled |
| Retention Rate | % of customers still active |
| ARPU | Average revenue per active user |
| Avg CLV | Average customer lifetime value |
| Avg NPS | Average net promoter score |

---

## 🔍 SQL Techniques Demonstrated

- **CTEs** (`WITH` clauses) for modular query structure
- **Window functions**: `LAG`, `RANK`, `NTILE`, `SUM OVER`
- **Aggregations**: `SUM`, `AVG`, `COUNT`, `GROUP BY`
- **Subqueries**: inline and correlated
- **JOIN patterns**: LEFT JOIN, derived table joins
- **CASE expressions** for conditional segmentation
- **Date functions**: `strftime` for period extraction

---

## 📦 Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3.9+ | Data generation, pipeline, dashboard |
| Pandas | Data manipulation and analysis |
| NumPy | Statistical distributions |
| SQLite (in-memory) | SQL query execution |
| Plotly Dash | Interactive web dashboard |
| Dash Bootstrap Components | Dashboard layout and styling |
| OpenPyXL | Excel report generation |

---

## 💡 Portfolio Talking Points

1. **Data Engineering** — Designed and generated a realistic 110K-row synthetic dataset with statistically plausible churn rates, revenue distributions, and NPS patterns.
2. **SQL Analytics** — Wrote production-quality SQL using CTEs, window functions, and multi-table join patterns to extract business insights.
3. **Python Pipeline** — Built a modular data pipeline with documented cleaning rules, automated KPI computation, and Excel reporting.
4. **Data Visualization** — Developed an interactive multi-page dashboard with dynamic filters and 9 chart types.
5. **Business Acumen** — Conducted Root Cause Analysis on customer cancellations with actionable recommendations.
