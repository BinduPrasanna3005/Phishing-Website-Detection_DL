"""
BA1 - Synthetic SaaS/E-commerce Dataset Generator
Generates 100,000+ realistic customer subscription records.
Run: python generate_data.py
"""

import pandas as pd
import numpy as np
import os
import warnings
from datetime import datetime, timedelta

# Reproducibility
np.random.seed(42)

OUTPUT_FILE = "saas_customers.csv"
N_RECORDS = 110_000

# ── Config ──────────────────────────────────────────────────────────────────
PLANS = {
    "Free":       {"price": 0,    "weight": 0.25, "churn_rate": 0.20},
    "Starter":    {"price": 29,   "weight": 0.30, "churn_rate": 0.12},
    "Professional":{"price": 99,  "weight": 0.28, "churn_rate": 0.08},
    "Enterprise": {"price": 399,  "weight": 0.17, "churn_rate": 0.04},
}

REGIONS = ["North America", "Europe", "Asia Pacific", "Latin America", "Middle East & Africa"]
REGION_WEIGHTS = [0.42, 0.28, 0.18, 0.08, 0.04]

CHANNELS = ["Organic Search", "Paid Ads", "Referral", "Direct", "Social Media", "Partner"]
CHANNEL_WEIGHTS = [0.30, 0.22, 0.18, 0.15, 0.10, 0.05]

INDUSTRIES = ["Technology", "Finance", "Healthcare", "Retail", "Education",
               "Manufacturing", "Media", "Consulting", "Real Estate", "Other"]

CANCELLATION_REASONS = [
    "Too Expensive",
    "Missing Features",
    "Switched to Competitor",
    "No Longer Needed",
    "Poor Customer Support",
    "Technical Issues",
    "Business Closure",
    "Downgraded to Free",
]
CANCEL_WEIGHTS = [0.28, 0.20, 0.18, 0.12, 0.09, 0.07, 0.04, 0.02]

START_DATE = datetime(2020, 1, 1)
END_DATE   = datetime(2024, 6, 30)
DATE_RANGE_DAYS = (END_DATE - START_DATE).days


def random_dates(n, start, days):
    offsets = np.random.randint(0, days, size=n)
    return [start + timedelta(days=int(d)) for d in offsets]


def build_dataset(n: int) -> pd.DataFrame:
    plan_names   = list(PLANS.keys())
    plan_weights = [PLANS[p]["weight"] for p in plan_names]

    plans    = np.random.choice(plan_names, size=n, p=plan_weights)
    regions  = np.random.choice(REGIONS,   size=n, p=REGION_WEIGHTS)
    channels = np.random.choice(CHANNELS,  size=n, p=CHANNEL_WEIGHTS)
    industries = np.random.choice(INDUSTRIES, size=n)

    signup_dates = random_dates(n, START_DATE, DATE_RANGE_DAYS)

    # Monthly revenue with small noise per customer
    base_prices = np.array([PLANS[p]["price"] for p in plans], dtype=float)
    noise = np.random.normal(0, 0.05, size=n)
    monthly_revenue = np.round(base_prices * (1 + noise), 2)
    monthly_revenue = np.clip(monthly_revenue, 0, None)

    # Company size (employees)
    company_size = np.random.choice(
        ["1-10", "11-50", "51-200", "201-1000", "1000+"],
        size=n,
        p=[0.30, 0.30, 0.22, 0.12, 0.06],
    )

    # NPS score (1-10)
    nps = np.random.choice(range(1, 11), size=n, p=[
        0.03, 0.03, 0.05, 0.07, 0.10, 0.12, 0.15, 0.18, 0.15, 0.12
    ])

    # Support tickets opened
    support_tickets = np.random.poisson(lam=2, size=n)

    # Churn decision per customer based on plan churn rate
    churn_rates = np.array([PLANS[p]["churn_rate"] for p in plans])
    # Adjust churn upward for low NPS
    nps_adj = np.where(nps <= 4, 0.08, np.where(nps >= 8, -0.02, 0.0))
    effective_churn = np.clip(churn_rates + nps_adj, 0.01, 0.60)
    churned_mask = np.random.rand(n) < effective_churn

    # Cancellation dates (1–365 days after signup, within END_DATE)
    cancel_dates = []
    cancel_reasons = []
    for i in range(n):
        if churned_mask[i]:
            max_days = (END_DATE - signup_dates[i]).days
            if max_days < 30:
                churned_mask[i] = False
                cancel_dates.append(None)
                cancel_reasons.append(None)
            else:
                days_active = int(np.random.exponential(scale=180))
                days_active = min(days_active, max_days)
                days_active = max(days_active, 30)
                cancel_dates.append(signup_dates[i] + timedelta(days=days_active))
                cancel_reasons.append(
                    np.random.choice(CANCELLATION_REASONS, p=CANCEL_WEIGHTS)
                )
        else:
            cancel_dates.append(None)
            cancel_reasons.append(None)

    # Months active
    reference = END_DATE
    months_active = []
    for i in range(n):
        end = cancel_dates[i] if cancel_dates[i] else reference
        delta = (end.year - signup_dates[i].year) * 12 + (end.month - signup_dates[i].month)
        months_active.append(max(delta, 1))

    # CLV: monthly_revenue × months_active
    clv = np.array([monthly_revenue[i] * months_active[i] for i in range(n)])
    clv = np.round(clv, 2)

    df = pd.DataFrame({
        "customer_id":      [f"CUST{str(i+1).zfill(6)}" for i in range(n)],
        "signup_date":      signup_dates,
        "plan":             plans,
        "region":           regions,
        "industry":         industries,
        "acquisition_channel": channels,
        "company_size":     company_size,
        "monthly_revenue":  monthly_revenue,
        "nps_score":        nps,
        "support_tickets":  support_tickets,
        "is_churned":       churned_mask.astype(int),
        "cancellation_date": cancel_dates,
        "cancellation_reason": cancel_reasons,
        "months_active":    months_active,
        "customer_lifetime_value": clv,
    })

    # Format dates
    df["signup_date"] = pd.to_datetime(df["signup_date"]).dt.strftime("%Y-%m-%d")
    df["cancellation_date"] = pd.to_datetime(df["cancellation_date"]).dt.strftime("%Y-%m-%d")

    return df


if __name__ == "__main__":
    if os.path.exists(OUTPUT_FILE):
        warnings.warn(f"WARNING: '{OUTPUT_FILE}' already exists and will be overwritten.")

    print(f"Generating {N_RECORDS:,} customer records...")
    df = build_dataset(N_RECORDS)

    total_churned = df["is_churned"].sum()
    churn_rate = total_churned / len(df) * 100
    print(f"  Total records     : {len(df):,}")
    print(f"  Churned customers : {total_churned:,} ({churn_rate:.1f}%)")
    print(f"  Total revenue (MRR est.): ${df['monthly_revenue'].sum():,.0f}")
    print(f"  Date range        : {df['signup_date'].min()} → {df['signup_date'].max()}")

    df.to_csv(OUTPUT_FILE, index=False)
    print(f"\nSaved → {os.path.abspath(OUTPUT_FILE)}")
