"""
BA1 - SQL Query Runner
Loads the CSV into an in-memory SQLite database and runs all SQL scripts.
Outputs results as Excel sheets in sql_results.xlsx.
Run: python run_sql_queries.py
"""

import os
import sqlite3
import pandas as pd
from pathlib import Path

CSV_FILE   = "saas_customers.csv"
OUTPUT_XLS = "sql_results.xlsx"
SQL_DIR    = "sql"

QUERIES = [
    ("01_mrr_trends_cte.sql",          "MRR_Trends"),
    ("02_window_functions_growth.sql",  "MoM_Growth"),
    ("03_clv_joins_subqueries.sql",     "CLV_Summary"),
    ("04_cancellation_analysis.sql",    "Cancellation_RCA"),
]


def load_data_to_sqlite(csv_path: str) -> sqlite3.Connection:
    print(f"Loading '{csv_path}' into SQLite...")
    df = pd.read_csv(csv_path)
    conn = sqlite3.connect(":memory:")
    df.to_sql("customers", conn, if_exists="replace", index=False)
    print(f"  Loaded {len(df):,} rows into table 'customers'")
    return conn


def run_query(conn: sqlite3.Connection, sql_path: str) -> pd.DataFrame:
    with open(sql_path, "r", encoding="utf-8") as f:
        sql = f.read()

    # Strip single-line comments and execute the main SELECT
    # SQLite doesn't support PERCENTILE natively; replace custom subquery pattern
    sql = sql.replace(
        """CASE
            WHEN c.customer_lifetime_value >= (
                SELECT PERCENTILE_APPROX_80 FROM (
                    SELECT MAX(sub.clv_80) AS PERCENTILE_APPROX_80
                    FROM (
                        SELECT plan,
                               monthly_revenue * 0.8 AS clv_80
                        FROM customers
                        WHERE plan = c.plan
                        LIMIT 1
                    ) sub
                )
            ) THEN 'High Value'
            WHEN c.customer_lifetime_value >= b.avg_clv_plan * 0.5 THEN 'Mid Value'
            ELSE 'Low Value'
        END""",
        """CASE
            WHEN c.customer_lifetime_value >= b.avg_clv_plan * 1.5 THEN 'High Value'
            WHEN c.customer_lifetime_value >= b.avg_clv_plan * 0.5 THEN 'Mid Value'
            ELSE 'Low Value'
        END"""
    )

    df = pd.read_sql_query(sql, conn)
    return df


def main():
    if not os.path.exists(CSV_FILE):
        print(f"ERROR: '{CSV_FILE}' not found. Please run generate_data.py first.")
        return

    conn = load_data_to_sqlite(CSV_FILE)

    results = {}
    for filename, sheet_name in QUERIES:
        sql_path = os.path.join(SQL_DIR, filename)
        if not os.path.exists(sql_path):
            print(f"  SKIP: {sql_path} not found")
            continue
        print(f"  Running {filename}...")
        try:
            df = run_query(conn, sql_path)
            results[sheet_name] = df
            print(f"    → {len(df):,} rows returned")
        except Exception as e:
            print(f"    ERROR in {filename}: {e}")

    conn.close()

    if results:
        print(f"\nWriting results to '{OUTPUT_XLS}'...")
        with pd.ExcelWriter(OUTPUT_XLS, engine="openpyxl") as writer:
            for sheet, df in results.items():
                df.to_excel(writer, sheet_name=sheet, index=False)
                print(f"  Sheet '{sheet}': {len(df):,} rows")
        print(f"Saved → {os.path.abspath(OUTPUT_XLS)}")
    else:
        print("No results to write.")


if __name__ == "__main__":
    main()
