"""
BA1 - Business Analytics Dashboard (Plotly Dash)
Displays KPIs, revenue trends, churn analysis, and cohort retention.
Run: python dashboard.py
Open browser at: http://127.0.0.1:8050
"""

import os
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from dash import Dash, dcc, html, Input, Output, callback
import dash_bootstrap_components as dbc
from datetime import datetime

CSV_FILE = "saas_customers_clean.csv"
RAW_CSV  = "saas_customers.csv"

# ── Color palette ─────────────────────────────────────────────────────────────
COLORS = {
    "primary":   "#2563EB",
    "success":   "#16A34A",
    "danger":    "#DC2626",
    "warning":   "#D97706",
    "info":      "#0891B2",
    "light_bg":  "#F8FAFC",
    "card_bg":   "#FFFFFF",
    "border":    "#E2E8F0",
    "text":      "#1E293B",
    "muted":     "#64748B",
}

PLAN_COLORS = {
    "Free":         "#94A3B8",
    "Starter":      "#60A5FA",
    "Professional": "#2563EB",
    "Enterprise":   "#1E3A8A",
}


# ── Data loading ──────────────────────────────────────────────────────────────
def load_data():
    # Prefer cleaned CSV, fall back to raw
    if os.path.exists(CSV_FILE):
        df = pd.read_csv(CSV_FILE, parse_dates=["signup_date", "cancellation_date"])
    elif os.path.exists(RAW_CSV):
        df = pd.read_csv(RAW_CSV, parse_dates=["signup_date", "cancellation_date"])
    else:
        return None

    df["signup_month"] = df["signup_date"].dt.to_period("M").astype(str)
    df["churn_month"]  = df["cancellation_date"].dt.to_period("M").astype(str)
    return df


# ── KPI helpers ────────────────────────────────────────────────────────────────
def compute_kpis(df):
    active  = df[df["is_churned"] == 0]
    churned = df[df["is_churned"] == 1]
    total   = len(df)
    return {
        "total_revenue":    df["customer_lifetime_value"].sum(),
        "mrr":              active["monthly_revenue"].sum(),
        "active_customers": len(active),
        "churn_rate":       len(churned) / total * 100 if total else 0,
        "retention_rate":   len(active) / total * 100 if total else 0,
        "arpu":             active["monthly_revenue"].mean() if len(active) else 0,
        "avg_clv":          df["customer_lifetime_value"].mean(),
        "avg_nps":          df["nps_score"].mean(),
    }


# ── KPI card component ────────────────────────────────────────────────────────
def kpi_card(title, value, subtitle="", color=COLORS["primary"], icon="📊"):
    return dbc.Card(
        dbc.CardBody([
            html.Div([
                html.Span(icon, style={"fontSize": "24px", "marginRight": "8px"}),
                html.Span(title, style={
                    "fontSize": "13px", "fontWeight": "600",
                    "color": COLORS["muted"], "textTransform": "uppercase",
                    "letterSpacing": "0.5px"
                }),
            ], style={"display": "flex", "alignItems": "center", "marginBottom": "8px"}),
            html.H3(value, style={
                "fontSize": "28px", "fontWeight": "700",
                "color": color, "margin": "0 0 4px 0"
            }),
            html.P(subtitle, style={
                "fontSize": "12px", "color": COLORS["muted"], "margin": "0"
            }),
        ]),
        style={
            "border": f"1px solid {COLORS['border']}",
            "borderRadius": "12px",
            "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
            "height": "100%",
        }
    )


# ── App init ──────────────────────────────────────────────────────────────────
app = Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    title="BA1 — Business Analytics Dashboard",
)

df_global = load_data()


def build_layout():
    if df_global is None:
        return dbc.Container([
            html.Div([
                html.H2("⚠️ Data Not Found", style={"color": COLORS["danger"]}),
                html.P("Please run the data generation script first:"),
                html.Code("python generate_data.py", style={
                    "background": "#F1F5F9", "padding": "8px 16px",
                    "borderRadius": "6px", "display": "block"
                }),
                html.P("Then optionally run the pipeline:"),
                html.Code("python data_pipeline.py"),
            ], style={"padding": "60px", "textAlign": "center"}),
        ], fluid=True)

    plans   = sorted(df_global["plan"].unique().tolist())
    regions = sorted(df_global["region"].unique().tolist())

    return dbc.Container([
        # ── Header ──────────────────────────────────────────────────────────
        dbc.Row([
            dbc.Col([
                html.H1("📊 Business Analytics Dashboard",
                        style={"fontWeight": "700", "color": COLORS["text"],
                               "marginBottom": "4px"}),
                html.P("SaaS KPI Monitoring | Revenue · Retention · Churn · Cohorts",
                       style={"color": COLORS["muted"], "marginBottom": "0"}),
            ], md=8),
            dbc.Col([
                html.Div([
                    html.Small("Last refreshed: " + datetime.now().strftime("%Y-%m-%d %H:%M"),
                               style={"color": COLORS["muted"]}),
                ], style={"textAlign": "right", "paddingTop": "12px"}),
            ], md=4),
        ], className="mb-3 mt-3"),

        # ── Filters ─────────────────────────────────────────────────────────
        dbc.Card([
            dbc.CardBody([
                dbc.Row([
                    dbc.Col([
                        html.Label("Plan", style={"fontWeight": "600", "fontSize": "13px"}),
                        dcc.Dropdown(
                            id="filter-plan",
                            options=[{"label": "All Plans", "value": "ALL"}] +
                                    [{"label": p, "value": p} for p in plans],
                            value="ALL",
                            clearable=False,
                            style={"fontSize": "13px"},
                        ),
                    ], md=3),
                    dbc.Col([
                        html.Label("Region", style={"fontWeight": "600", "fontSize": "13px"}),
                        dcc.Dropdown(
                            id="filter-region",
                            options=[{"label": "All Regions", "value": "ALL"}] +
                                    [{"label": r, "value": r} for r in regions],
                            value="ALL",
                            clearable=False,
                            style={"fontSize": "13px"},
                        ),
                    ], md=3),
                    dbc.Col([
                        html.Label("Date Range (Signup)", style={"fontWeight": "600", "fontSize": "13px"}),
                        dcc.RangeSlider(
                            id="filter-year",
                            min=df_global["signup_date"].dt.year.min(),
                            max=df_global["signup_date"].dt.year.max(),
                            step=1,
                            value=[
                                df_global["signup_date"].dt.year.min(),
                                df_global["signup_date"].dt.year.max(),
                            ],
                            marks={y: str(y) for y in range(
                                df_global["signup_date"].dt.year.min(),
                                df_global["signup_date"].dt.year.max() + 1,
                            )},
                        ),
                    ], md=6),
                ]),
            ])
        ], className="mb-4", style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),

        # ── KPI Cards ────────────────────────────────────────────────────────
        html.Div(id="kpi-cards", className="mb-4"),

        # ── Charts Row 1 ─────────────────────────────────────────────────────
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("📈 Monthly Revenue Trend", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-mrr-trend", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=8),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🍕 Revenue by Plan", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-plan-pie", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=4),
        ], className="mb-4"),

        # ── Charts Row 2 ─────────────────────────────────────────────────────
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🚪 Cancellation Reasons", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-cancel-reasons", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=5),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("📉 Monthly Churn Rate", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-churn-trend", style={"height": "320px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=7),
        ], className="mb-4"),

        # ── Charts Row 3 ─────────────────────────────────────────────────────
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🗓️ Cohort Retention Heatmap", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-cohort", style={"height": "380px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=7),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("🌍 Revenue by Region", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-region", style={"height": "380px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=5),
        ], className="mb-4"),

        # ── Charts Row 4: CLV Distribution ───────────────────────────────────
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("💰 Customer Lifetime Value Distribution", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-clv-dist", style={"height": "300px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=6),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader(html.H6("📊 NPS Distribution by Plan", className="mb-0",
                                           style={"fontWeight": "600"})),
                    dbc.CardBody([dcc.Graph(id="chart-nps", style={"height": "300px"})]),
                ], style={"borderRadius": "12px", "border": f"1px solid {COLORS['border']}"}),
            ], md=6),
        ], className="mb-5"),

        # Footer
        html.Hr(),
        html.P("BA1 Business Analytics Portfolio Project | Built with Python & Plotly Dash",
               style={"textAlign": "center", "color": COLORS["muted"], "fontSize": "12px"}),

    ], fluid=True, style={"backgroundColor": COLORS["light_bg"], "minHeight": "100vh"})


app.layout = build_layout()


# ── Callbacks ─────────────────────────────────────────────────────────────────
def apply_filters(df, plan, region, year_range):
    filtered = df.copy()
    if plan != "ALL":
        filtered = filtered[filtered["plan"] == plan]
    if region != "ALL":
        filtered = filtered[filtered["region"] == region]
    filtered = filtered[
        (filtered["signup_date"].dt.year >= year_range[0]) &
        (filtered["signup_date"].dt.year <= year_range[1])
    ]
    return filtered


@app.callback(
    Output("kpi-cards", "children"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_kpi_cards(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)
    kpis = compute_kpis(df)

    return dbc.Row([
        dbc.Col(kpi_card("Total Revenue", f"${kpis['total_revenue']:,.0f}",
                         "All-time CLV sum", COLORS["primary"], "💵"), md=3),
        dbc.Col(kpi_card("Current MRR",   f"${kpis['mrr']:,.0f}",
                         "Active customers only", COLORS["success"], "📈"), md=3),
        dbc.Col(kpi_card("Active Customers", f"{kpis['active_customers']:,}",
                         "Not yet churned", COLORS["info"], "👥"), md=3),
        dbc.Col(kpi_card("Churn Rate",    f"{kpis['churn_rate']:.1f}%",
                         f"Retention: {kpis['retention_rate']:.1f}%", COLORS["danger"], "🚪"), md=3),
        dbc.Col(kpi_card("ARPU",          f"${kpis['arpu']:.2f}",
                         "Avg revenue per active user", COLORS["warning"], "💡"), md=3),
        dbc.Col(kpi_card("Avg CLV",       f"${kpis['avg_clv']:,.0f}",
                         "Avg lifetime value", COLORS["primary"], "🏆"), md=3),
        dbc.Col(kpi_card("Avg NPS",       f"{kpis['avg_nps']:.1f}/10",
                         "Customer satisfaction score", COLORS["success"], "⭐"), md=3),
        dbc.Col(kpi_card("Total Customers", f"{len(df):,}",
                         "In selected filter", COLORS["info"], "📋"), md=3),
    ])


@app.callback(
    Output("chart-mrr-trend", "figure"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_mrr_trend(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)

    monthly = df.groupby("signup_month").agg(
        new_mrr=("monthly_revenue", "sum"),
        signups=("customer_id", "count"),
    ).reset_index().sort_values("signup_month")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=monthly["signup_month"], y=monthly["new_mrr"],
        mode="lines+markers", name="Monthly Revenue",
        line=dict(color=COLORS["primary"], width=2),
        marker=dict(size=4),
        fill="tozeroy", fillcolor="rgba(37,99,235,0.1)",
    ))

    fig.update_layout(
        margin=dict(t=10, b=40, l=50, r=10),
        xaxis_title="Month", yaxis_title="Revenue ($)",
        plot_bgcolor="white", paper_bgcolor="white",
        xaxis=dict(tickangle=45, tickfont=dict(size=10)),
        yaxis=dict(tickformat="$,.0f"),
        showlegend=False,
        hovermode="x unified",
    )
    return fig


@app.callback(
    Output("chart-plan-pie", "figure"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_plan_pie(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)
    by_plan = df[df["is_churned"] == 0].groupby("plan")["monthly_revenue"].sum().reset_index()

    fig = px.pie(
        by_plan, values="monthly_revenue", names="plan",
        color="plan",
        color_discrete_map=PLAN_COLORS,
        hole=0.4,
    )
    fig.update_traces(textposition="inside", textinfo="percent+label")
    fig.update_layout(
        margin=dict(t=10, b=10, l=10, r=10),
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.2),
        plot_bgcolor="white", paper_bgcolor="white",
    )
    return fig


@app.callback(
    Output("chart-cancel-reasons", "figure"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_cancel_reasons(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)
    churned = df[df["is_churned"] == 1]

    if len(churned) == 0:
        fig = go.Figure()
        fig.add_annotation(text="No churn data", showarrow=False)
        return fig

    by_reason = churned.groupby("cancellation_reason").agg(
        count=("customer_id", "count"),
        lost_mrr=("monthly_revenue", "sum"),
    ).reset_index().sort_values("count", ascending=True)

    fig = go.Figure(go.Bar(
        y=by_reason["cancellation_reason"],
        x=by_reason["count"],
        orientation="h",
        marker_color=COLORS["danger"],
        text=by_reason["count"],
        textposition="outside",
    ))
    fig.update_layout(
        margin=dict(t=10, b=40, l=10, r=30),
        xaxis_title="Cancellations",
        plot_bgcolor="white", paper_bgcolor="white",
        yaxis=dict(tickfont=dict(size=11)),
    )
    return fig


@app.callback(
    Output("chart-churn-trend", "figure"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_churn_trend(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)

    signups = df.groupby("signup_month")["customer_id"].count().reset_index()
    signups.columns = ["month", "signups"]

    churned = df[df["is_churned"] == 1].copy()
    churned["cm"] = churned["cancellation_date"].dt.to_period("M").astype(str)
    churn_m = churned.groupby("cm")["customer_id"].count().reset_index()
    churn_m.columns = ["month", "churns"]

    merged = signups.merge(churn_m, on="month", how="left").fillna(0)
    merged["churn_rate"] = (merged["churns"] / merged["signups"] * 100).round(2)
    merged = merged.sort_values("month")

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=merged["month"], y=merged["churns"],
        name="Churned", marker_color=COLORS["danger"], opacity=0.7,
        yaxis="y",
    ))
    fig.add_trace(go.Scatter(
        x=merged["month"], y=merged["churn_rate"],
        name="Churn Rate %", mode="lines+markers",
        line=dict(color=COLORS["warning"], width=2),
        yaxis="y2",
    ))
    fig.update_layout(
        margin=dict(t=10, b=50, l=50, r=60),
        xaxis=dict(tickangle=45, tickfont=dict(size=10)),
        yaxis=dict(title="Churned Customers", side="left"),
        yaxis2=dict(title="Churn Rate (%)", overlaying="y", side="right",
                    tickformat=".1f"),
        plot_bgcolor="white", paper_bgcolor="white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        hovermode="x unified",
    )
    return fig


@app.callback(
    Output("chart-cohort", "figure"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_cohort(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)
    df2 = df.copy()
    df2["cohort"] = df2["signup_date"].dt.to_period("M").astype(str)

    cohort_sizes = df2.groupby("cohort")["customer_id"].count().rename("size")
    active = df2[df2["is_churned"] == 0].groupby("cohort")["customer_id"].count().rename("active")

    ret = pd.concat([cohort_sizes, active], axis=1).reset_index()
    ret["active"] = ret["active"].fillna(0)
    ret["retention"] = (ret["active"] / ret["size"] * 100).round(1)
    ret = ret.sort_values("cohort").tail(24)  # last 24 months

    fig = go.Figure(go.Bar(
        x=ret["cohort"],
        y=ret["retention"],
        marker=dict(
            color=ret["retention"],
            colorscale="RdYlGn",
            cmin=0, cmax=100,
            showscale=True,
            colorbar=dict(title="Retention %", thickness=12),
        ),
        text=[f"{v:.0f}%" for v in ret["retention"]],
        textposition="outside",
    ))
    fig.update_layout(
        margin=dict(t=10, b=60, l=50, r=60),
        xaxis=dict(tickangle=45, tickfont=dict(size=9)),
        yaxis=dict(title="Retention Rate (%)", range=[0, 115]),
        plot_bgcolor="white", paper_bgcolor="white",
    )
    return fig


@app.callback(
    Output("chart-region", "figure"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_region(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)
    by_region = df.groupby("region").agg(
        total_customers=("customer_id", "count"),
        total_mrr=("monthly_revenue", lambda x: x[df.loc[x.index, "is_churned"] == 0].sum()),
        churn_count=("is_churned", "sum"),
    ).reset_index()
    by_region["churn_rate"] = (by_region["churn_count"] / by_region["total_customers"] * 100).round(1)

    fig = px.bar(
        by_region.sort_values("total_customers", ascending=False),
        x="region", y="total_customers",
        color="churn_rate",
        color_continuous_scale="RdYlGn_r",
        text="total_customers",
        labels={"total_customers": "Customers", "churn_rate": "Churn %"},
    )
    fig.update_traces(texttemplate="%{text:,}", textposition="outside")
    fig.update_layout(
        margin=dict(t=10, b=60, l=50, r=60),
        xaxis=dict(tickangle=15),
        plot_bgcolor="white", paper_bgcolor="white",
        coloraxis_colorbar=dict(title="Churn %", thickness=12),
    )
    return fig


@app.callback(
    Output("chart-clv-dist", "figure"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_clv_dist(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)

    fig = go.Figure()
    for p, color in PLAN_COLORS.items():
        subset = df[df["plan"] == p]["customer_lifetime_value"]
        if len(subset) > 0:
            fig.add_trace(go.Histogram(
                x=subset.clip(0, subset.quantile(0.99)),
                name=p, opacity=0.75,
                marker_color=color,
                nbinsx=40,
            ))

    fig.update_layout(
        barmode="overlay",
        margin=dict(t=10, b=40, l=50, r=10),
        xaxis_title="Customer LTV ($)", yaxis_title="Count",
        plot_bgcolor="white", paper_bgcolor="white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
        xaxis=dict(tickformat="$,.0f"),
    )
    return fig


@app.callback(
    Output("chart-nps", "figure"),
    Input("filter-plan", "value"),
    Input("filter-region", "value"),
    Input("filter-year", "value"),
)
def update_nps(plan, region, year_range):
    df = apply_filters(df_global, plan, region, year_range)

    nps_by_plan = df.groupby(["plan", "nps_score"])["customer_id"].count().reset_index()
    nps_by_plan.columns = ["plan", "nps_score", "count"]

    fig = px.bar(
        nps_by_plan, x="nps_score", y="count",
        color="plan", barmode="group",
        color_discrete_map=PLAN_COLORS,
        labels={"nps_score": "NPS Score (1-10)", "count": "Customers"},
    )
    fig.update_layout(
        margin=dict(t=10, b=40, l=50, r=10),
        plot_bgcolor="white", paper_bgcolor="white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
        xaxis=dict(tickmode="linear", dtick=1),
    )
    return fig


if __name__ == "__main__":
    print("=" * 60)
    print("  BA1 — Business Analytics Dashboard")
    print("  Open: http://127.0.0.1:8050")
    print("=" * 60)
    if df_global is None:
        print("WARNING: No dataset found. Run generate_data.py first.")
    app.run(debug=False, host="127.0.0.1", port=8050)
