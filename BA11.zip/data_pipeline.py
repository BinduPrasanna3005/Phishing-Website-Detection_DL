"""
BA1 - Data Pipeline: Cleaning, KPI Computation, Automated Reporting
Reads the raw CSV, cleans it, computes KPIs, exports Excel report.
Run: python data_pipeline.py
"""

import os
import warnings
import pandas as pd
import numpy as np
from datetime import datetime

RAW_CSV     = "saas_customers.csv"
CLEAN_CSV   = "saas_customers_clean.csv"
REPORT_XLS  = "BA1_Analytics_Report.xlsx"
REFERENCE_DATE = pd.Timestamp("2024-06-30")


# ── 1. LOAD ──────────────────────────────────────────────────────────────────
def load_data(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        raise FileNotFoundError(f"'{path}' not found. Run generate_data.py first.")
    df = pd.read_csv(path, parse_dates=["signup_date", "cancellation_date"])
    print(f"Loaded {len(df):,} rows from '{path}'")
    return df


# ── 2. CLEAN ─────────────────────────────────────────────────────────────────
def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    original_len = len(df)

    # Drop rows with no customer_id or signup_date (critical fields)
    df = df.dropna(subset=["customer_id", "signup_date"])

    # Fill missing plan with mode
    mode_plan = df["plan"].mode()[0]
    missing_plan = df["plan"].isna().sum()
    df["plan"] = df["plan"].fillna(mode_plan)
    if missing_plan:
        print(f"  Filled {missing_plan} missing plan values with '{mode_plan}'")

    # Fill missing region with 'Unknown'
    missing_region = df["region"].isna().sum()
    df["region"] = df["region"].fillna("Unknown")
    if missing_region:
        print(f"  Filled {missing_region} missing region values with 'Unknown'")

    # Fill missing monthly_revenue with 0 for Free plan, plan median otherwise
    plan_medians = df.groupby("plan")["monthly_revenue"].median()
    def fill_revenue(row):
        if pd.isna(row["monthly_revenue"]):
            return 0 if row["plan"] == "Free" else plan_medians.get(row["plan"], 0)
        return row["monthly_revenue"]
    df["monthly_revenue"] = df.apply(fill_revenue, axis=1)

    # Remove negative revenue rows
    neg_rev = (df["monthly_revenue"] < 0).sum()
    df = df[df["monthly_revenue"] >= 0]
    if neg_rev:
        print(f"  Removed {neg_rev} rows with negative monthly_revenue")

    # Fix is_churned: ensure consistent with cancellation_date presence
    df["is_churned"] = df["is_churned"].fillna(0).astype(int)
    # If cancellation_date is present but is_churned=0, fix it
    has_cancel_date = df["cancellation_date"].notna()
    mismatch = (has_cancel_date & (df["is_churned"] == 0)).sum()
    df.loc[has_cancel_date & (df["is_churned"] == 0), "is_churned"] = 1
    if mismatch:
        print(f"  Fixed {mismatch} rows: had cancellation_date but is_churned=0")

    # Validate cancellation_date is after signup_date
    bad_dates = (
        df["cancellation_date"].notna() &
        (df["cancellation_date"] <= df["signup_date"])
    ).sum()
    df = df[~(
        df["cancellation_date"].notna() &
        (df["cancellation_date"] <= df["signup_date"])
    )]
    if bad_dates:
        print(f"  Removed {bad_dates} rows: cancellation_date ≤ signup_date")

    # Clip NPS to 1-10
    df["nps_score"] = df["nps_score"].clip(1, 10)

    # months_active: recompute to ensure accuracy
    def calc_months(row):
        end = row["cancellation_date"] if pd.notna(row["cancellation_date"]) else REFERENCE_DATE
        delta = (end.year - row["signup_date"].year) * 12 + (end.month - row["signup_date"].month)
        return max(delta, 1)
    df["months_active"] = df.apply(calc_months, axis=1)

    # Recompute CLV
    df["customer_lifetime_value"] = (df["monthly_revenue"] * df["months_active"]).round(2)

    # Add derived columns
    df["signup_year"]  = df["signup_date"].dt.year
    df["signup_month"] = df["signup_date"].dt.to_period("M").astype(str)

    removed = original_len - len(df)
    print(f"  Cleaning complete: {len(df):,} rows remain ({removed} removed)")
    return df


# ── 3. KPIs ──────────────────────────────────────────────────────────────────
def compute_kpis(df: pd.DataFrame) -> dict:
    active = df[df["is_churned"] == 0]
    churned = df[df["is_churned"] == 1]

    total_customers  = len(df)
    active_customers = len(active)
    churned_customers = len(churned)
    churn_rate       = churned_customers / total_customers * 100
    retention_rate   = 100 - churn_rate
    total_mrr        = active["monthly_revenue"].sum()
    total_revenue    = df["customer_lifetime_value"].sum()
    arpu             = total_mrr / active_customers if active_customers else 0
    avg_clv          = df["customer_lifetime_value"].mean()
    avg_nps          = df["nps_score"].mean()
    avg_months       = df["months_active"].mean()

    return {
        "Total Customers":        total_customers,
        "Active Customers":       active_customers,
        "Churned Customers":      churned_customers,
        "Churn Rate (%)":         round(churn_rate, 2),
        "Retention Rate (%)":     round(retention_rate, 2),
        "Total MRR ($)":          round(total_mrr, 2),
        "Total Revenue ($)":      round(total_revenue, 2),
        "ARPU ($)":               round(arpu, 2),
        "Avg Customer LTV ($)":   round(avg_clv, 2),
        "Avg NPS Score":          round(avg_nps, 2),
        "Avg Months Active":      round(avg_months, 1),
    }


# ── 4. MONTHLY TRENDS ────────────────────────────────────────────────────────
def monthly_trends(df: pd.DataFrame) -> pd.DataFrame:
    df["signup_month_dt"] = df["signup_date"].dt.to_period("M")

    monthly = df.groupby("signup_month_dt").agg(
        new_signups     = ("customer_id", "count"),
        new_mrr         = ("monthly_revenue", "sum"),
        avg_mrr         = ("monthly_revenue", "mean"),
    ).reset_index()

    churned_m = df[df["is_churned"] == 1].copy()
    churned_m["churn_month_dt"] = churned_m["cancellation_date"].dt.to_period("M")
    churn_by_month = churned_m.groupby("churn_month_dt").agg(
        cancellations   = ("customer_id", "count"),
        lost_mrr        = ("monthly_revenue", "sum"),
    ).reset_index().rename(columns={"churn_month_dt": "signup_month_dt"})

    monthly = monthly.merge(churn_by_month, on="signup_month_dt", how="left")
    monthly["cancellations"] = monthly["cancellations"].fillna(0).astype(int)
    monthly["lost_mrr"]      = monthly["lost_mrr"].fillna(0)
    monthly["net_mrr"]       = monthly["new_mrr"] - monthly["lost_mrr"]
    monthly["cumulative_mrr"] = monthly["new_mrr"].cumsum()
    monthly["signup_month_dt"] = monthly["signup_month_dt"].astype(str)
    monthly = monthly.sort_values("signup_month_dt")
    monthly.columns = [c.replace("_dt", "") for c in monthly.columns]

    for col in ["new_mrr", "avg_mrr", "lost_mrr", "net_mrr", "cumulative_mrr"]:
        monthly[col] = monthly[col].round(2)

    return monthly


# ── 5. CHURN ANALYSIS ────────────────────────────────────────────────────────
def churn_analysis(df: pd.DataFrame) -> pd.DataFrame:
    churned = df[df["is_churned"] == 1].copy()
    churned["churn_month"] = churned["cancellation_date"].dt.to_period("M").astype(str)

    by_reason = churned.groupby("cancellation_reason").agg(
        cancellations  = ("customer_id", "count"),
        lost_mrr       = ("monthly_revenue", "sum"),
        avg_mrr_lost   = ("monthly_revenue", "mean"),
        avg_months     = ("months_active", "mean"),
        avg_nps        = ("nps_score", "mean"),
    ).reset_index()

    total_c = by_reason["cancellations"].sum()
    by_reason["pct_of_cancellations"] = (
        by_reason["cancellations"] / total_c * 100
    ).round(2)

    by_reason = by_reason.sort_values("lost_mrr", ascending=False).reset_index(drop=True)
    for col in ["lost_mrr", "avg_mrr_lost", "avg_months", "avg_nps"]:
        by_reason[col] = by_reason[col].round(2)

    return by_reason


# ── 6. COHORT RETENTION ──────────────────────────────────────────────────────
def cohort_retention(df: pd.DataFrame) -> pd.DataFrame:
    df2 = df.copy()
    df2["cohort"] = df2["signup_date"].dt.to_period("M").astype(str)

    cohort_sizes = df2.groupby("cohort")["customer_id"].count().rename("cohort_size")
    active_by_cohort = df2[df2["is_churned"] == 0].groupby("cohort")["customer_id"].count().rename("retained")

    retention = pd.concat([cohort_sizes, active_by_cohort], axis=1).reset_index()
    retention["retained"] = retention["retained"].fillna(0).astype(int)
    retention["retention_rate_pct"] = (
        retention["retained"] / retention["cohort_size"] * 100
    ).round(1)
    retention = retention.sort_values("cohort")
    return retention


# ── 7. PLAN PERFORMANCE ───────────────────────────────────────────────────────
def plan_performance(df: pd.DataFrame) -> pd.DataFrame:
    perf = df.groupby("plan").agg(
        total_customers   = ("customer_id", "count"),
        active_customers  = ("is_churned", lambda x: (x == 0).sum()),
        churned_customers = ("is_churned", "sum"),
        total_mrr         = ("monthly_revenue", lambda x: x[df.loc[x.index, "is_churned"] == 0].sum()),
        avg_mrr           = ("monthly_revenue", "mean"),
        avg_clv           = ("customer_lifetime_value", "mean"),
        total_clv         = ("customer_lifetime_value", "sum"),
        avg_nps           = ("nps_score", "mean"),
        avg_months        = ("months_active", "mean"),
    ).reset_index()

    perf["churn_rate_pct"] = (
        perf["churned_customers"] / perf["total_customers"] * 100
    ).round(2)

    for col in ["total_mrr", "avg_mrr", "avg_clv", "total_clv", "avg_nps", "avg_months"]:
        perf[col] = perf[col].round(2)

    return perf


# ── 8. RCA ────────────────────────────────────────────────────────────────────
def root_cause_analysis(df: pd.DataFrame, churn_df: pd.DataFrame) -> pd.DataFrame:
    top3_by_count = churn_df.nlargest(3, "cancellations")[["cancellation_reason", "cancellations", "lost_mrr", "pct_of_cancellations"]]

    rows = []
    for _, r in top3_by_count.iterrows():
        reason = r["cancellation_reason"]
        subset = df[(df["is_churned"] == 1) & (df["cancellation_reason"] == reason)]
        top_plan   = subset["plan"].value_counts().idxmax() if len(subset) else "N/A"
        top_region = subset["region"].value_counts().idxmax() if len(subset) else "N/A"
        avg_nps    = subset["nps_score"].mean() if len(subset) else np.nan

        rows.append({
            "Rank":                   len(rows) + 1,
            "Cancellation Reason":    reason,
            "Total Cancellations":    int(r["cancellations"]),
            "% of All Cancellations": r["pct_of_cancellations"],
            "Lost MRR ($)":           round(r["lost_mrr"], 2),
            "Most Affected Plan":     top_plan,
            "Most Affected Region":   top_region,
            "Avg NPS (churned)":      round(avg_nps, 2) if not pd.isna(avg_nps) else "N/A",
            "Recommended Action":     _get_recommendation(reason),
        })

    return pd.DataFrame(rows)


def _get_recommendation(reason: str) -> str:
    mapping = {
        "Too Expensive":            "Introduce discounted annual billing; offer downgrade path to lower tier.",
        "Missing Features":         "Prioritize feature gap analysis; engage churned users in product roadmap surveys.",
        "Switched to Competitor":   "Conduct win/loss analysis; accelerate differentiator features.",
        "No Longer Needed":         "Improve onboarding to demonstrate value earlier; reduce time-to-value.",
        "Poor Customer Support":    "Reduce first-response SLA; add self-service help centre.",
        "Technical Issues":         "Improve uptime SLAs; add proactive incident communication.",
        "Business Closure":         "Offer pause/freeze option instead of full cancellation.",
        "Downgraded to Free":       "Improve free-to-paid conversion with in-app upsell prompts.",
    }
    return mapping.get(reason, "Investigate further with customer interviews.")


# ── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("  BA1 DATA PIPELINE")
    print("=" * 60)

    df_raw = load_data(RAW_CSV)

    print("\n[2] Cleaning data...")
    df = clean_data(df_raw)
    df.to_csv(CLEAN_CSV, index=False)
    print(f"  Saved clean data → {os.path.abspath(CLEAN_CSV)}")

    print("\n[3] Computing KPIs...")
    kpis = compute_kpis(df)
    for k, v in kpis.items():
        print(f"  {k:<30} {v:>15,}" if isinstance(v, (int, float)) else f"  {k:<30} {v}")

    print("\n[4] Computing monthly trends...")
    monthly  = monthly_trends(df)

    print("\n[5] Churn analysis...")
    churn    = churn_analysis(df)

    print("\n[6] Cohort retention...")
    cohort   = cohort_retention(df)

    print("\n[7] Plan performance...")
    plan_perf = plan_performance(df)

    print("\n[8] Root Cause Analysis...")
    rca = root_cause_analysis(df, churn)
    print("\n  Top 3 Cancellation Drivers:")
    for _, row in rca.iterrows():
        print(f"    #{int(row['Rank'])}: {row['Cancellation Reason']} "
              f"({row['Total Cancellations']:,} cancellations, "
              f"${row['Lost MRR ($)']:,.0f} lost MRR)")

    print(f"\n[9] Writing Excel report → '{REPORT_XLS}'...")
    kpi_df = pd.DataFrame(list(kpis.items()), columns=["KPI", "Value"])

    with pd.ExcelWriter(REPORT_XLS, engine="openpyxl") as writer:
        kpi_df.to_excel(writer,      sheet_name="KPI Summary",      index=False)
        monthly.to_excel(writer,     sheet_name="Monthly Trends",    index=False)
        churn.to_excel(writer,       sheet_name="Churn Analysis",    index=False)
        cohort.to_excel(writer,      sheet_name="Cohort Retention",  index=False)
        plan_perf.to_excel(writer,   sheet_name="Plan Performance",  index=False)
        rca.to_excel(writer,         sheet_name="RCA",               index=False)

    print(f"  Saved → {os.path.abspath(REPORT_XLS)}")
    print("\nPipeline complete.")


if __name__ == "__main__":
    main()
